package dev.experto.demo.exception;

public class ApiWebClientException extends RuntimeException {
    public ApiWebClientException(String msg) {
        super(msg);
    }
}
