package com.gp.demokafka;

import com.gp.demokafka.model.User;
import com.gp.demokafka.producer.KafkaJsonProducer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {

    private final KafkaJsonProducer jsonProducer;

    public CommandLineAppStartupRunner(KafkaJsonProducer jsonProducer) {
        this.jsonProducer = jsonProducer;
    }

    @Override
    public void run(String... args) throws Exception {
        //  jsonProducer.sendMessage(new User("Larry","juarez"));
        // jsonProducer.sendMessage(new User("The Edge"));

        // jsonProducer.sendMessage(new User("Charly"));

        // File path is passed as parameter
        File file = new File(
                "C:\\Users\\berna\\OneDrive\\Documents\\kafka\\test.txt");
        String User;
        String splitBy = ",";
        String line = null;
        BufferedReader br = new BufferedReader(new FileReader(file));
        while((line = br.readLine()) != null){
            String[] b = line.split(splitBy);
        jsonProducer.sendMessage(new User(b[0],b[1]));
           // System.out.println(b[1]);
        }

    }
}