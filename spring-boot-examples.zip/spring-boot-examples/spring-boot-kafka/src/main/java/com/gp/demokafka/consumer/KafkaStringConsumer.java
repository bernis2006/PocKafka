package com.gp.demokafka.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;


public class KafkaStringConsumer {

    Logger logger = LoggerFactory.getLogger(KafkaStringConsumer.class);

    @KafkaListener(topics = "nrtPoc" , groupId = "nrtPoc")
    public void consume(String message) {
        logger.info("Consuming Message {}", message);
    }

}
