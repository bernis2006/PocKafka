# Integrating Swagger into Spring Boot

How to integrate Swagger with our Spring Boot application.

[Swagger Spring Boot Integration](https://gustavopeiretti.com/spring-boot-swagger-integration/)
