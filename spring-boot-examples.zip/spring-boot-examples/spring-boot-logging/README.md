# Spring Boot Logs

Example about how to create logs with Spring Boot

* [Spring Boot Logs](https://gustavopeiretti.com/logging-with-spring-boot)

### Reference Documentation
For further reference, please consider the following sections:

* [Spring Boot Logs](https://docs.spring.io/spring-boot/docs/2.1.13.RELEASE/reference/html/boot-features-logging.html)



