# Spring Boot Create Schema and Load Init Data example

Example about how to load init data in Spring Boot

* [Spring Boot Database initialization sql files](https://gustavopeiretti.com/)


