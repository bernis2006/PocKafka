INSERT INTO user (id, birth_date, name, surname)
VALUES (1, '1960-06-10', 'Paul', 'Hewson');
INSERT INTO user (id, birth_date, name, surname)
VALUES (2, '1960-03-13', 'Adam', 'Clayton');
INSERT INTO user (id, birth_date, name, surname)
VALUES (3, '1961-08-08', 'David', 'Evans');