# How to send email with Spring Boot 

Example of how to send email with Spring Boot 

