/*
 * 
 */
package mx.santander.nrt.replicator.service;

import java.util.List;
import mx.santander.nrt.replicator.model.Record;

/**
 * The Interface IAuditService.
 */
public interface ILogService {
	
	/**
	 * Send audit messages.
	 *
	 * @param messages
	 *            the messages to save
	 */
	void sendAuditMessages(List<Record> messages);

}