/*
 * 
 */
package mx.santander.nrt.replicator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
//import mx.santander.nrt.monitoring.health.lib.replicator.ReplicatorHealthLibConfig


/**
 * The Class ReplicatorServiceApplication.
 */
@SpringBootApplication
// Disable class from Spring Boot Autoconfigure
@EnableAutoConfiguration(exclude={MongoAutoConfiguration.class})
@ComponentScan({"mx.santander.nrt","mx.santander.pid"})
//@ComponentScan(basePackageClasses = { ReplicatorHealthLibConfig.class })
public class ReplicatorServiceApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(ReplicatorServiceApplication.class, args);
	}

}
