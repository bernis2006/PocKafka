/*
 * 
 */
package mx.santander.nrt.replicator.datasource.mongo.repository;

import java.util.List;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mongodb.MongoBulkWriteException;
import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.BulkWriteOptions;
import com.mongodb.client.model.WriteModel;


/**
 * DAO que contiene metodos para la interacion con MongoDB.
 * 
 * @author Platform & Services
 * 
 */
// @Repository annotation is not necessary, the service initialize the corresponding repository according the configuration  
public class MongoRepository implements IMongoRepository {
	/** La Constante LOGGER. Obtiene el Logger de la clase. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MongoRepository.class);

	/** The collection. */
	private final MongoCollection<Document> collection;

	/**
	 * Instantiates a new mongo DB repository.
	 *
	 * @param collection the collection
	 */
	public MongoRepository(MongoCollection<Document> collection) {
		this.collection = collection;
	}

	/**
	 * Metodo que permite realizar un bulkWrite a la coleccion especificada.
	 *
	 * @param requests the requests
	 * @return true if all inserts, updates, replaces, and deletes are successfully
	 *         executes, and the number of documents inserted, updated, replaced and
	 *         deleted by the write operation are more that zero otherwise return
	 *         false.
	 */
	@Override
	public boolean bulkWrite(List<WriteModel<Document>> requests) {
		LOGGER.trace("Records number: {}", requests.size());
		try {
			BulkWriteResult result = collection.bulkWrite(requests, new BulkWriteOptions().ordered(false));				
			LOGGER.info(":: RESULTADOS BULKWRITE: TOTAL {} - DELETED {} - MODIFIED {} - INSERTED {} - UPSERTS {}", requests.size(), result.getDeletedCount(), result.getModifiedCount(), result.getInsertedCount(), result.getUpserts().size());
			return true;
		} catch (MongoBulkWriteException e) {
			LOGGER.error("Error al propagar mensajes {}", e);
			LOGGER.error(":: RESULTADOS DE ERRORES GENERALES: {} - {} ::", e.getWriteResult(),e.getWriteErrors().size());
		}
		return false;
	}
}
