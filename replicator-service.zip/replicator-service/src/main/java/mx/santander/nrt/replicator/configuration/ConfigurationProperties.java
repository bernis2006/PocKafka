/*
 * 
 */
package mx.santander.nrt.replicator.configuration;

import java.util.Map.Entry;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import mx.santander.nrt.replicator.configuration.mapping.PropertiesMapping;
import mx.santander.nrt.replicator.configuration.model.Channel;
import mx.santander.nrt.replicator.configuration.model.DataSourceConfig;
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;
import mx.santander.nrt.replicator.configuration.model.RecordConfiguration;


/**
 * The Class ConfigurationProperties.
 */
@Component
public class ConfigurationProperties implements IConfigurationProperties {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationProperties.class);

	/** The properties mapping. */
	private final PropertiesMapping propertiesMapping;

	/**
	 * Instantiates a new configuration properties.
	 *
	 * @param propertiesMapping the properties mapping
	 */
	public ConfigurationProperties(PropertiesMapping propertiesMapping) {
		this.propertiesMapping = propertiesMapping;
	}
	
	/**
	 * Prints the configuration.
	 */
	@PostConstruct
	public void printConfiguration() {
		LOGGER.info(":::Replicator Service Configuration: {}", propertiesMapping.toString());
	}

	/**
	 * Gets the table to replicate.
	 *
	 * @param tableName the table name
	 * @return the table to replicate
	 */
	@Override
	public RecordConfiguration getTableToReplicate(String tableName) {
		return propertiesMapping.getTableToReplicate(tableName);

	}

	/**
	 * Gets the default channel.
	 *
	 * @return the default channel
	 */
	@Override
	public Channel getDefaultChannel() {
		DataSourceConfig dataSourceConfig = propertiesMapping.getDatasourceConfig();
		Entry<String, Channel> firtEntry = dataSourceConfig.getChannels().entrySet().iterator().next();
		Channel defaultChannel = firtEntry.getValue();
		defaultChannel.setName(firtEntry.getKey());
		String defaultDataSourceName = dataSourceConfig.getDefaultDataSource();
		if (defaultDataSourceName != null) {
			defaultChannel = dataSourceConfig.getChannels().get(defaultDataSourceName);
			defaultChannel.setName(defaultDataSourceName);
		}
		return defaultChannel;
	}

	/**
	 * Gets the object config by data source and object name.
	 *
	 * @param dataSource the data source
	 * @param objectName the object name
	 * @return the object config by data source and object name
	 */
	@Override
	public ObjectConfig getObjectConfigByDataSourceAndObjectName(String dataSource, String objectName) {
		return propertiesMapping.getObjectConfigByDatasource(dataSource).get(objectName);
	}
	
	/**
	 * Gets the configuration.
	 *
	 * @return the configuration
	 */
	@Override
	public PropertiesMapping getConfiguration() {
		return propertiesMapping;
	}

}
