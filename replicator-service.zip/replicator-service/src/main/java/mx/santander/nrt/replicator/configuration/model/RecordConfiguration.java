/*
 * 
 */
package mx.santander.nrt.replicator.configuration.model;

import java.io.Serializable;
import java.util.Map;


/**
 * The Class RecordConfiguration.
 */
public class RecordConfiguration implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The fields config. */
	private Map<String, FieldConfiguration> fieldsConfig;

	/**
	 * Gets the fields config.
	 *
	 * @return the fields config
	 */
	public Map<String, FieldConfiguration> getFieldsConfig() {
		return fieldsConfig;
	}

	/**
	 * Sets the fields config.
	 *
	 * @param fieldsConfig the fields config
	 */
	public void setFieldsConfig(Map<String, FieldConfiguration> fieldsConfig) {
		this.fieldsConfig = fieldsConfig;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{\"fieldsConfig\":" + fieldsConfig + "}";
	}
	
	

}
