/*
 * 
 */
package mx.santander.nrt.replicator.configuration;

import mx.santander.nrt.replicator.configuration.mapping.PropertiesMapping;
import mx.santander.nrt.replicator.configuration.model.Channel;
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;
import mx.santander.nrt.replicator.configuration.model.RecordConfiguration;


/**
 * The Interface IConfigurationProperties.
 */
public interface IConfigurationProperties {

	/**
	 * Gets the table to replicate.
	 *
	 * @param tableName the table name
	 * @return the table to replicate
	 */
	RecordConfiguration getTableToReplicate(String tableName);

	/**
	 * Gets the default channel.
	 *
	 * @return the default channel
	 */
	Channel getDefaultChannel();
	
	/**
	 * Gets the object config by data source and object name.
	 *
	 * @param dataSource the data source
	 * @param objectName the object name
	 * @return the object config by data source and object name
	 */
	ObjectConfig getObjectConfigByDataSourceAndObjectName(String dataSource, String objectName);

	/**
	 * Gets the configuration.
	 *
	 * @return the configuration
	 */
	PropertiesMapping getConfiguration();

}
