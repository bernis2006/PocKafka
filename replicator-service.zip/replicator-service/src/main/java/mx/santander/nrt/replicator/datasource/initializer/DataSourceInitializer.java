/*
 * 
 */
package mx.santander.nrt.replicator.datasource.initializer;

import org.bson.BsonDocument;
import org.bson.BsonInt64;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.model.Channel;
import mx.santander.nrt.replicator.datasource.IDataSource;
import mx.santander.nrt.replicator.datasource.KafkaDataSource;
import mx.santander.nrt.replicator.datasource.MongoDataSource;
import mx.santander.nrt.replicator.datasource.OracleDataSource;
import mx.santander.nrt.replicator.datasource.mongo.repository.MongoRepository;


//The class RepositoryInitializer is responsible to select the correct data destination.
/**
 * The Class DataSourceInitializer.
 */
//The data destination is defined with externalized configuration through .yml file
@Component
public class DataSourceInitializer {

	/**
	 * Data source.
	 *
	 * @param configurationProperties the configuration properties
	 * @return the i data source
	 */
	@Bean
	public IDataSource dataSource(IConfigurationProperties configurationProperties) {
//		Define current DataSource implementation 
//		-Mongo.
//		-Kafka.
//		-Oracle.
		IDataSource dataSource = null;
		Channel channelConfig = configurationProperties.getDefaultChannel();
		switch (channelConfig.getName()) {
		case "mongo":
			MongoClient mongoClient = MongoClients.create(channelConfig.getUrl());
			MongoDatabase mongoDatabase = mongoClient.getDatabase(channelConfig.getDatabase());
			if (channelConfig.testOnInit()){
				mongoDatabase.runCommand(new BsonDocument("ping", new BsonInt64(1)));
			}
			dataSource = new MongoDataSource(configurationProperties, new MongoRepository(mongoDatabase.getCollection(channelConfig.getCollectionName())));
			break;
		case "oracle":
			dataSource = new OracleDataSource(configurationProperties);
			break;
		case "kafka":
			dataSource = new KafkaDataSource(configurationProperties);
			break;
		default:
			break;
		}
		return dataSource;
	}
}