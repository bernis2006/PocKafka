/*
 * 
 */
package mx.santander.nrt.replicator.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.model.FieldConfiguration;
import mx.santander.nrt.replicator.configuration.model.RecordConfiguration;
import mx.santander.nrt.replicator.model.Record;


/**
 * The Class RecordProcessor.
 */
@Component
public class RecordProcessor implements IRecordProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(RecordProcessor.class);

	/** The configuration properties. */
	private final IConfigurationProperties configurationProperties;

	/**
	 * Instantiates a new record processor.
	 *
	 * @param configurationProperties the configuration properties
	 */
	public RecordProcessor(IConfigurationProperties configurationProperties) {
		this.configurationProperties = configurationProperties;
	}

	/**
	 * Transform message.
	 *
	 * @param currentRecords the records
	 * @return the list
	 */
	@Override
	public List<Record> transformMessage(List<Record> currentRecords) {
		// Method to transform the message format, the format is according the configuration
		List<Record> transformedMessages = new ArrayList<Record>();
		for (Record currentRecord : currentRecords) {
			// For each message get the table name.
			String tableName = currentRecord.getMetadata().getTableName();
			// Get the table configuration
			RecordConfiguration recordConfig = configurationProperties.getTableToReplicate(tableName);
			Map<String, FieldConfiguration> fieldsConfig = recordConfig.getFieldsConfig();
			Map<String, Object> transformedMessage = new HashMap<String, Object>();
			for (Entry<String, FieldConfiguration> fieldConfig : fieldsConfig.entrySet()) {
				// For each fieldConfig, get the location and transform to json tree.
				String fieldName = fieldConfig.getKey();
				String value = currentRecord.getData().get(fieldName);
				String location = fieldConfig.getValue().getLocation();
				if (transformedMessage.isEmpty()) {
					nodeToJsonProperty(null, location, transformedMessage, value);
				} else {
					Node<String, String, Map<String, Object>> node = getLastNodeInfo(null, location, transformedMessage);
					nodeToJsonProperty(node.getParentNodeName(), node.getNodeName(), node.getValue(), value);
				}
			}
			// Add transformedMessage, tableName and operationType into object.
			transformedMessages.add(new Record(currentRecord.getMetadata(), transformedMessage));
		}
		LOGGER.trace("MAP LOCATION: {}", transformedMessages);
		return transformedMessages;
	}

	/**
	 * Gets the last node info.
	 *
	 * @param currentNodeLocation the current node location
	 * @param subPath the sub path
	 * @param currentTransformedMessage the current transformed message
	 * @return the last node info
	 */
	private Node<String, String, Map<String, Object>> getLastNodeInfo(String currentNodeLocation, String subPath, Map<String, Object> currentTransformedMessage) {
		LOGGER.trace("currentNodeLocation: {}, subPath: {}, currentTransformedMessage: {}",currentNodeLocation, subPath, currentTransformedMessage);
		String[] tmpNodeLocation = subPath.split("\\.", 2);
		if (!(tmpNodeLocation.length <= 1)) {
			// Node is not the last
			Node<String, String, Map<String, Object>> tmpParentNodeTest = new Node<String, String, Map<String,Object>>(tmpNodeLocation[0], tmpNodeLocation[1], currentTransformedMessage);
			if (currentNodeLocation == null && currentTransformedMessage.containsKey(tmpNodeLocation[0])) {
				tmpParentNodeTest = new Node<String, String, Map<String, Object>>(
						getLastNodeInfo(tmpNodeLocation[0], tmpNodeLocation[1], currentTransformedMessage));
			} else if (currentTransformedMessage.containsKey(currentNodeLocation)) {
				tmpParentNodeTest = new Node<String, String, Map<String, Object>>(
						getLastNodeInfo(tmpNodeLocation[0],	tmpNodeLocation[1], (Map<String, Object>) currentTransformedMessage.get(currentNodeLocation)));
			} else if (!currentTransformedMessage.containsKey(tmpNodeLocation[0])) {
				return new Node<String, String, Map<String, Object>>(currentNodeLocation, subPath, currentTransformedMessage);
			}
			return tmpParentNodeTest;
		} else {
			return new Node<String, String, Map<String, Object>>(currentNodeLocation, subPath, currentTransformedMessage);
		}
	}
	
	/**
	 * Node to json property.
	 *
	 * @param currentNodeLocation the current node location
	 * @param subPath the sub path
	 * @param currentTransformedMessage the current transformed message
	 * @param value the value
	 */
	public void nodeToJsonProperty(String currentNodeLocation, String subPath,Map<String, Object> currentTransformedMessage, String value) {
		LOGGER.trace("currentNodeLocation: {}, subPath: {}, currentTransformedMessage: {}, value: {}",currentNodeLocation, subPath, currentTransformedMessage, value);
		String[] tmpNodeLocation = subPath.split("\\.", 2);
		Map<String, Object> node = new HashMap<String, Object>();
		if (tmpNodeLocation.length > 1) {
			// Node is not the last
			if (currentNodeLocation == null) {
				currentTransformedMessage.put(tmpNodeLocation[0], value);
				nodeToJsonProperty(tmpNodeLocation[0], tmpNodeLocation[1], currentTransformedMessage, value);
			} else {
				node.put(tmpNodeLocation[0], value);
				if (!(currentTransformedMessage.get(currentNodeLocation) instanceof Map)) {
					currentTransformedMessage.put(currentNodeLocation, node);
					nodeToJsonProperty(tmpNodeLocation[0], tmpNodeLocation[1], node, value);
				} else {
					Map<String, Object> valueMap = (Map<String, Object>) currentTransformedMessage.get(currentNodeLocation);
					valueMap.put(currentNodeLocation, node);
					nodeToJsonProperty(tmpNodeLocation[0], tmpNodeLocation[1], node, value);
				}
			}
		}  else {
			// Node is the last
			if (currentNodeLocation == null) {
				currentTransformedMessage.put(tmpNodeLocation[0], value);
			} else if (currentTransformedMessage.get(currentNodeLocation) instanceof Map) {
				Map<String, Object> valueMap = (Map<String, Object>) currentTransformedMessage.get(currentNodeLocation);
				valueMap.put(tmpNodeLocation[0], value);
			} else {
				node.put(tmpNodeLocation[0], value);
				currentTransformedMessage.put(currentNodeLocation, node);
			}
		}
	}

	/**
	 * The Class Node.
	 *
	 * @param <P> the generic type
	 * @param <N> the number type
	 * @param <V> the value type
	 */
	class Node<P, N, V> {
		
		/** The parent node name. */
		private P parentNodeName;
		
		/** The node name. */
		private N nodeName;
		
		/** The value. */
		private V value;

		/**
		 * Instantiates a new node.
		 *
		 * @param parentNodeName the parent node name
		 * @param nodeName the node name
		 * @param value the value
		 */
		public Node(P parentNodeName, N nodeName, V value) {
			this.parentNodeName = parentNodeName;
			this.nodeName = nodeName;
			this.value = value;
		}

		/**
		 * Instantiates a new node.
		 *
		 * @param node the node
		 */
		public Node(Node<P, N, V> node) {
			this.parentNodeName = node.getParentNodeName();
			this.nodeName = node.getNodeName();
			this.value = node.getValue();
		}

		/**
		 * Gets the parent node name.
		 *
		 * @return the parent node name
		 */
		public P getParentNodeName() {
			return parentNodeName;
		}

		/**
		 * Gets the node name.
		 *
		 * @return the node name
		 */
		public N getNodeName() {
			return nodeName;
		}

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public V getValue() {
			return value;
		}
	}
}