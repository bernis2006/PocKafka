/*
 * 
 */
package mx.santander.nrt.replicator.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * Clase que almacena los metadatos contenidos en el mensaje que se lee desde el
 * topico de Kafka.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Metadata implements Serializable {

	/**  Serial version. */
	private static final long serialVersionUID = 1L;

	/**  table_name. */
	@JsonProperty("table_name")
	private String tableName;

	/**  operation_utc_ts. */
	@JsonProperty("operation_utc_ts")
	private String operationUtcTs;

	/**  commit_cycle_id. */
	@JsonProperty("commit_cycle_id")
	private long commitCycleId;

	/**  operation_ts. */
	@JsonProperty("operation_ts")
	private String operationTs;

	/**  operation_type. */
	@JsonProperty("operation_type")
	private String operationType;

	/**  transform_ts. */
	@JsonProperty("transform_ts")
	private String transformTs;
	
	/** The buc. */
	private String buc;

	/**
	 * Instantiates a new metadata.
	 */
	public Metadata() {
		// Auto-generated constructor stub
	}

	/**
	 * Gets the table name.
	 *
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * Sets the table name.
	 *
	 * @param tableName the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * Gets the operation utc ts.
	 *
	 * @return the operationUtcTs
	 */
	public String getOperationUtcTs() {
		return operationUtcTs;
	}

	/**
	 * Sets the operation utc ts.
	 *
	 * @param operationUtcTs the operationUtcTs to set
	 */
	public void setOperationUtcTs(String operationUtcTs) {
		this.operationUtcTs = operationUtcTs;
	}

	/**
	 * Gets the commit cycle id.
	 *
	 * @return the commitCycleId
	 */
	public long getCommitCycleId() {
		return commitCycleId;
	}

	/**
	 * Sets the commit cycle id.
	 *
	 * @param commitCycleId the commitCycleId to set
	 */
	public void setCommitCycleId(long commitCycleId) {
		this.commitCycleId = commitCycleId;
	}

	/**
	 * Gets the operation ts.
	 *
	 * @return the operationTs
	 */
	public String getOperationTs() {
		return operationTs;
	}

	/**
	 * Sets the operation ts.
	 *
	 * @param operationTs the operationTs to set
	 */
	public void setOperationTs(String operationTs) {
		this.operationTs = operationTs;
	}

	/**
	 * Gets the operation type.
	 *
	 * @return the operationType
	 */
	public String getOperationType() {
		return operationType;
	}

	/**
	 * Sets the operation type.
	 *
	 * @param operationType the operationType to set
	 */
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	/**
	 * Gets the transform ts.
	 *
	 * @return the transformTs
	 */
	public String getTransformTs() {
		return transformTs;
	}

	/**
	 * Sets the transform ts.
	 *
	 * @param transformTs the transformTs to set
	 */
	public void setTransformTs(String transformTs) {
		this.transformTs = transformTs;
	}
	
	/**
	 * Gets the buc.
	 *
	 * @return the buc
	 */
	public String getBuc() {
		return buc;
	}

	/**
	 * Sets the buc.
	 *
	 * @param buc the new buc
	 */
	public void setBuc(String buc) {
		this.buc = buc;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{'tableName':'" + tableName + "', 'operationUtcTs':'" + operationUtcTs + "', 'commitCycleId':"
				+ commitCycleId + ", 'operationTs':'" + operationTs + "', 'operationType':'" + operationType
				+ "', 'transformTs':'" + transformTs + "', 'buc':'" + buc + "'}";
	}

}