/*
 * 
 */
package mx.santander.nrt.replicator.datasource.mongo.processor;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bson.BsonDocument;
import org.bson.Document;
import org.bson.conversions.Bson;
import com.mongodb.client.model.WriteModel;
//import mx.santander.nrt.monitoring.health.lib.replicator.model.annotation.IdentifyRefreshOperation
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;

/**
 * The Class MongoPreProcessor.
 */
public class MongoPreProcessor extends MongoOperationsBuilder {
	
	/**
	 * Instantiates a new mongo pre processor.
	 */
	private MongoPreProcessor() {
		// private constructor to hide the implicit public one
	}

	/**
	 * Transform message.
	 *
	 * @param objectConfig the object config
	 * @param message the message
	 * @param operationType the operation type
	 * @return the list
	 */
//	@IdentifyRefreshOperation(argumentIndex = 2, flujosReplicacion = "customerMe", spelPath = "#root")
	public static List<WriteModel<Document>> transformMessage(ObjectConfig objectConfig, Map<String, Object> message, String operationType) {		
		List<WriteModel<Document>> operations = new ArrayList<WriteModel<Document>>();
		switch (operationType) {
		case "I":
		case "U":
		case "R":
			List<String> primaryFilterItem = Arrays.asList(objectConfig.getPrimaryFilter());
			castValue(objectConfig.getObjectTypeConfig(), message);
			List<Bson> filters = buildEqFiltersByItem(primaryFilterItem, message);
			BsonDocument bsonDocumentFilter = filters.get(0).toBsonDocument();
			// Object in collection
			if (objectConfig.isCollectionElement()) {
				// Add operation to insert principal object only if not exist
				operations.add(buildSetOperation(bsonDocumentFilter, bsonDocumentFilter));
				// Add operation to delete object only if exist
				Node<String, Map<String,Object>> nodeInfo = getSubObject(null, message);
				operations.add(buildPullOperation(objectConfig, message, nodeInfo, filters));
				// Add operation to create object
				operations.add(buildPushOperation(bsonDocumentFilter, nodeInfo));
				// Object in no collection
			} else {
				// Add operation to create object
				Map<String, Object> fields = new HashMap<String, Object>();
				mapToPropertiesFormat(null, message, fields);
				operations.add(buildSetOperation(bsonDocumentFilter, fields));
			}
			break;
		case "D":
			primaryFilterItem = Arrays.asList(objectConfig.getPrimaryFilter());
			castValue(objectConfig.getObjectTypeConfig(), message);
			filters = buildEqFiltersByItem(primaryFilterItem, message);
			bsonDocumentFilter = filters.get(0).toBsonDocument();
			// Object in collection
			if (objectConfig.isCollectionElement()) {
				// Add operation to delete object only if exist
				Node<String, Map<String,Object>> nodeInfo = getSubObject(null, message);				
				operations.add(buildPullOperation(objectConfig, message, nodeInfo, filters));
				// Object in no collection
			} else {
				Map<String, Object> fields = new HashMap<String, Object>();
				mapToPropertiesFormat(null, message, fields);
				Map<String,Object> keys = new HashMap<String,Object>();
				fields.forEach((k,v) -> {
					if (!k.equals(objectConfig.getPrimaryFilter())) {
						keys.put(k, v);
					}
				});
				operations.add(buildUnSetOperation(bsonDocumentFilter, keys));
			}
			break;
		default:
			break;
		}
		LOGGER.debug("OPERATIONS: {}", operations);
		return operations;
	}

	// OK
	// Transform message (map format) to properties format. 
	/**
	 * Map to properties format.
	 *
	 * @param path the path
	 * @param message the message
	 * @param fields the fields
	 */
	// For each property in message, get location (full path) and value.  
	private static void mapToPropertiesFormat(String path, Map<String, Object> message, Map<String, Object> fields) {
		LOGGER.trace("path: {}, message: {}, fields: {}",path, message, fields);
		message.forEach((k,v) ->{
			String tmpPath = k;
			if (path != null) {
				tmpPath = path.concat(".").concat(k);
			}
			if (v instanceof Map) {
				mapToPropertiesFormat(tmpPath, (Map<String, Object>) v, fields);
			} else {
				fields.put(tmpPath, v);
			}
		});
	}
	
	/**
	 * Cast value.
	 *
	 * @param castConfig the cast config
	 * @param message the message
	 */
	private static void castValue(Map<String,String> castConfig, Map<String, Object> message) {
		if (castConfig != null) {
			castConfig.forEach((location, type) -> {
				// Get value
				castValue(null, location, message, type);
			});
		}
	}
	
	/**
	 * Cast value.
	 *
	 * @param currentPath the current path
	 * @param subPath the sub path
	 * @param message the message
	 * @param type the type
	 */
	// TODO: Send message to "Invalid message queue"
	private static void castValue(String currentPath, String subPath, Map<String, Object> message, String type) {
		LOGGER.trace("currentPath: {}, subPath: {}, message: {}",currentPath, subPath, message);
		String[] tmpNodeLocation = subPath.split("\\.", 2);
		if (!(tmpNodeLocation.length <= 1) && (message.containsKey(tmpNodeLocation[0])) && (message.get(tmpNodeLocation[0]) instanceof Map)) {
			// Node is not the last
			if (currentPath == null) {
				castValue(tmpNodeLocation[0], tmpNodeLocation[1],(Map<String, Object>) message.get(tmpNodeLocation[0]), type);
			} else {
				castValue(currentPath.concat(tmpNodeLocation[0]), tmpNodeLocation[1],(Map<String, Object>) message.get(tmpNodeLocation[0]), type);
			}
		} else {
			// Node is the last
			String value = (String) message.get(tmpNodeLocation[0]);
			Object castedValue = String.valueOf(value);
			switch (type) {
			case "int":
				castedValue = Integer.valueOf(value);
				break;
			case "long":
				castedValue = Long.valueOf(value);
				break;
			case "double":
				castedValue = Double.valueOf(value);
				break;
			case "date":
				castedValue = Date.valueOf(value);
				break;
			case "timestamp":
				castedValue = Timestamp.valueOf(value);
				break;
			default:
				break;
			}
			message.put(tmpNodeLocation[0], castedValue);
		}
	}
	
	// OK
	// Get a sub object inside the message 
	// Define the sub common path, return this with the value (Object)
	// Example:
	// In the following message:
	// {"id": 1,"object1":{"object2":{"object3":{"String1": "value1","object4": {"string2": "value2"}}}}}
	// The sub common path is: object1.object2.object3
	/**
	 * Map to object.
	 *
	 * @param path the path
	 * @param message the message
	 * @return the node
	 */
	// The value is: {"String1": "value1","object4": {"string2": "value2"}}
	private static Node<String, Map<String, Object>> getSubObject(String path, Map<String, Object> message) {
		// Get common path
		Map<String, Object> fields = new HashMap<String, Object>();
		for (Entry<String, Object> node : message.entrySet()) {
			if (node.getValue() instanceof Map) {
				if (path == null) {
					path = node.getKey();
				} else {
					path = path.concat(".").concat(node.getKey());
				}
				if (((Map<String, Object>) node.getValue()).size() > 1) {
					// Get Object as map
					mapToPropertiesFormat(null, (Map<String, Object>) node.getValue(), fields);
					break;
				} else {
					return getSubObject(path, (Map<String, Object>) node.getValue());
				}
			}
		}
		 return new Node<String, Map<String,Object>>(path, fields);
	}
	
	/**
	 * The Class Node.
	 *
	 * @param <P> the generic type
	 * @param <V> the value type
	 */
	static class Node<P,V>{
		
		/** The path. */
		private P path;
		
		/** The value. */
		private V value;
		
		/**
		 * Instantiates a new node.
		 *
		 * @param path the path
		 * @param value the value
		 */
		public Node(P path, V value) {
			this.path = path;
			this.value = value;
		}
		
		/**
		 * Gets the path.
		 *
		 * @return the path
		 */
		public P getPath() {
			return path;
		}
		
		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public V getValue() {
			return value;
		}
	}

}
