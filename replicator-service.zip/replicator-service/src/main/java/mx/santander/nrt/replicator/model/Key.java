/*
 * 
 */
package mx.santander.nrt.replicator.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class Key.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Key implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The buc. */
	private String buc;
	
	/**
	 * Instantiates a new message.
	 */
	public Key() {
		// Auto-generated constructor stub
	}

	/**
	 * Gets the buc.
	 *
	 * @return the buc
	 */
	public String getBuc() {
		return buc;
	}

	/**
	 * Sets the buc.
	 *
	 * @param buc the new buc
	 */
	public void setBuc(String buc) {
		this.buc = buc;
	}
	
}