/*
 * 
 */
package mx.santander.nrt.replicator.configuration.model;

import java.io.Serializable;

/**
 * The Class Channel.
 */
public class Channel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The name. */
	private String name;

	/** The url. */
	private String url;

	/** The database. */
	private String database;

	/** The collection name. */
	private String collectionName;

	/** The username. */
	private String username;

	/** The password. */
	private String password;

	/** The drive classs name. */
	private String driveClasssName;

	/** The validation query. */
	private String validationQuery;
	
	/** The test on init. */
	private boolean testOnInit;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Gets the database.
	 *
	 * @return the database
	 */
	public String getDatabase() {
		return database;
	}

	/**
	 * Sets the database.
	 *
	 * @param database the new database
	 */
	public void setDatabase(String database) {
		this.database = database;
	}

	/**
	 * Gets the collection name.
	 *
	 * @return the collection name
	 */
	public String getCollectionName() {
		return collectionName;
	}

	/**
	 * Sets the collection name.
	 *
	 * @param collectionName the new collection name
	 */
	public void setCollectionName(String collectionName) {
		this.collectionName = collectionName;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the username.
	 *
	 * @param username the new username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the drive classs name.
	 *
	 * @return the drive classs name
	 */
	public String getDriveClasssName() {
		return driveClasssName;
	}

	/**
	 * Sets the drive classs name.
	 *
	 * @param driveClasssName the new drive classs name
	 */
	public void setDriveClasssName(String driveClasssName) {
		this.driveClasssName = driveClasssName;
	}

	/**
	 * Gets the validation query.
	 *
	 * @return the validation query
	 */
	public String getValidationQuery() {
		return validationQuery;
	}

	/**
	 * Sets the validation query.
	 *
	 * @param validationQuery the new validation query
	 */
	public void setValidationQuery(String validationQuery) {
		this.validationQuery = validationQuery;
	}
	
	/**
	 * Sets the test on init.
	 *
	 * @param testOnInit the new test on init
	 */
	public void setTestOnInit(boolean testOnInit) {
		this.testOnInit = testOnInit;
	}
	
	/**
	 * Test on init.
	 *
	 * @return true, if successful
	 */
	public boolean testOnInit() {
		return testOnInit;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		String tmpUrl = null;
		if (url != null) {
			tmpUrl = "hidden";
		}
		String tmpParameter = null;
		if (password != null) {
			tmpParameter = "hidden";
		}
		return "{\"name\":" + name + ", \"url\":\"" + tmpUrl + "\", \"database\":\"" + database + "\", \"collectionName\":\""
				+ collectionName + "\", \"username\":\"" + username + "\", \"password\":\"" + tmpParameter + "\", \"driveClasssName\":"
				+ driveClasssName + "\", \"validationQuery\":\"" + validationQuery + "\", \"testOnInit\":" + testOnInit + "\"}";
	}

}