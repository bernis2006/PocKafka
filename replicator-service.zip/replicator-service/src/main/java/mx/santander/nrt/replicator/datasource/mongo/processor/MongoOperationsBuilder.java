/*
 * 
 */
package mx.santander.nrt.replicator.datasource.mongo.processor;

import static com.mongodb.client.model.Updates.pull;
import static com.mongodb.client.model.Updates.push;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bson.BsonDocument;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOneModel;
import com.mongodb.client.model.UpdateOptions;
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;
import mx.santander.nrt.replicator.datasource.mongo.processor.MongoPreProcessor.Node;

/**
 * The Class MongoOperationsBuilder.
 */
public class MongoOperationsBuilder {
	
	/** The Constant LOGGER. */
	protected static final Logger LOGGER = LoggerFactory.getLogger(MongoPreProcessor.class);
	
	/**
	 * Instantiates a new mongo operations builder.
	 */
	protected MongoOperationsBuilder() {
		// private constructor to hide the implicit public one
	}
	
	/**
	 * Builds the push operation.
	 *
	 * @param bsonDocumentFilter the bson document filter
	 * @param nodeInfo the node info
	 * @return the update one model
	 */
	protected static UpdateOneModel<Document> buildPushOperation(BsonDocument bsonDocumentFilter, Node<String, Map<String, Object>> nodeInfo) {
		// Add operation to create object
		return new UpdateOneModel<Document>(bsonDocumentFilter,
			push(nodeInfo.getPath(), nodeInfo.getValue()));
		//	db.collection.updateOne(
		//		{
		//			"id":"1"
		//		},
		//		{
		//			"$push":{
		//				"algoArrayAn.algoArray":{
		//					"id1":"1",
		//					"id2":"2",
		//					"id3":"3",
		//					"algoString":"algo0"
		//				}
		//			}
		//		}
		//	)
	}
	
	/**
	 * Builds the un set operation.
	 *
	 * @param bsonDocumentFilter the bson document filter
	 * @param keys the keys
	 * @return the update one model
	 */
	protected static UpdateOneModel<Document> buildUnSetOperation(BsonDocument bsonDocumentFilter, Map<String,Object> keys) {
		// Build operation to delete object
		return new UpdateOneModel<Document>(bsonDocumentFilter, // Filters.eq(bsonDocumentFilter.toJson()),
				new Document("$unset", keys));
		//	db.collection.updateOne(
		//		{
		//			"id":"1"
		//		}, 
		//		{
		//			"$unset":{
		//				"id":""
		//			}
		//		}
		//	)
	}

	/**
	 * Builds the set operation.
	 *
	 * @param bsonDocumentFilter the bson document filter
	 * @param fields the fields
	 * @return the update one model
	 */
	protected static UpdateOneModel<Document> buildSetOperation(BsonDocument bsonDocumentFilter, Object fields) {
		// Build operation to create object
		return new UpdateOneModel<Document>(bsonDocumentFilter,// Filters.eq(bsonDocumentFilter.toJson()),
			new Document("$set", fields), new UpdateOptions().upsert(true));
		//	db.collection.updateOne(
		//		{
		//			"id":"1"
		//		}, 
		//		{
		//			"$set":{
		//				"id":"1"
		//			}
		//		},{
		//			"upsert":true
		//		}
		//	)
	}

	/**
	 * Builds the pull operation.
	 *
	 * @param objectConfig the object config
	 * @param message the message
	 * @param nodeInfo the node info
	 * @param filters the primary filter
	 * @return the update one model
	 */
	protected static UpdateOneModel<Document> buildPullOperation(ObjectConfig objectConfig, Map<String, Object> message, Node<String, Map<String, Object>> nodeInfo, List<Bson> filters) {
		//Build operation to delete object
		filters.addAll(buildEqFiltersByItem(objectConfig.getSecondaryFilters(), message));
//		List<Bson> subFilters = buildEqFiltersByItem(objectConfig.getSecondaryFilters(), message);
		// Filter map (nodeInfo) by secondaryFilters
		Map<String, Object> filteredObject = filterObjectProperties(objectConfig.getSecondaryFilters(), nodeInfo.getPath(), nodeInfo.getValue());
		return new UpdateOneModel<Document>(Filters.and(filters),
			pull(nodeInfo.getPath(), filteredObject));
		//	db.collection.updateOne(
		//		{
		//			"id":"1", 
		//			"algoArrayAn.algoArray.id1": "1",
		//			"algoArrayAn.algoArray.id2": "2",
		//			"algoArrayAn.algoArray.id3": "3"
		//		},
		//		{
		//			"$pull":{
		//				"algoArrayAn.algoArray":{
		//					"id1":"1",
		//					"id2":"2",
		//					"id3":"3"
		//				}
		//			}
		//		}
		//	)
	}
	
	/**
	 * Filter object properties.
	 *
	 * @param locations the locations
	 * @param commonPath the common path
	 * @param value the value
	 * @return the map
	 */
	// The first parameter contains a location lists (full path format), for each location, get the value and build the filter with the full path and value
	private static Map<String, Object> filterObjectProperties(List<String> locations, String commonPath, Map<String, Object> value) {
		Map<String, Object> filteredObject = new HashMap<String, Object>();
		locations.forEach(location -> {
			String subLocation = location.split(commonPath)[1];
			subLocation = subLocation.replaceFirst(".", "");
			filteredObject.put(subLocation, value.get(subLocation));
		});
		return filteredObject;
	}
	
	// OK
	// Build an equals filter for each item.
	// The first parameter contains a location lists (full path format), for each location, get the value and build the filter with the full path and value
	/**
	 * Builds the eq filters by item.
	 *
	 * @param locations the locations
	 * @param message the message
	 * @return the list
	 */
	// The value is searching inside the message, in the corresponding location.
	protected static List<Bson> buildEqFiltersByItem(List<String> locations, Map<String, Object> message) {
		List<Bson> filters = new ArrayList<Bson>();
		locations.forEach(location -> {
			// Get value
			Node<String, String> node = getNodeInfo(null, location, message);
			LOGGER.trace("value: {}", node.getValue());
			filters.add(Filters.eq(location, node.getValue()));
		});
		return filters;
	}
	
	// OK
	// Get a node object with a location and with the corresponding value.
	// The subPath parameter contain the location in properties format.
	/**
	 * Gets the node info.
	 *
	 * @param currentPath the current path
	 * @param subPath the sub path
	 * @param message the message
	 * @return the node info
	 */
	// The value is searching inside the message, in the corresponding location.
	private static Node<String, String> getNodeInfo(String currentPath, String subPath, Map<String, Object> message) {
		LOGGER.trace("currentPath: {}, subPath: {}, message: {}",currentPath, subPath, message);
		String[] tmpNodeLocation = subPath.split("\\.", 2);
		Object value = message.get(tmpNodeLocation[0]);
		if (!(tmpNodeLocation.length <= 1) && (message.containsKey(tmpNodeLocation[0])) && (message.get(tmpNodeLocation[0]) instanceof Map)) {
			// Node is not the last
			if (currentPath == null) {
				return getNodeInfo(tmpNodeLocation[0], tmpNodeLocation[1],(Map<String, Object>) message.get(tmpNodeLocation[0]));
			} else {
				return getNodeInfo(currentPath.concat(tmpNodeLocation[0]), tmpNodeLocation[1],(Map<String, Object>) message.get(tmpNodeLocation[0]));
			}
			
		} else {
			// Node is the last
			return new Node<String, String>(currentPath, (String) value);
		}
	}

}