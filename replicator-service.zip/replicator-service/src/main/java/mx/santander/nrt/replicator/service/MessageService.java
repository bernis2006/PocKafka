/*
 * 
 */
package mx.santander.nrt.replicator.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import mx.santander.nrt.replicator.datasource.IDataSource;
import mx.santander.nrt.replicator.model.Record;
import mx.santander.nrt.replicator.processor.IRecordProcessor;


/**
 * The Class MessageService.
 */
@Service
public class MessageService implements IMessageService {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageService.class);

	/** The record processor. */
	private final IRecordProcessor recordProcessor;
	
	/** The message data source. */
	private final IDataSource messageDataSource;
	
	private final ILogService logService;

	/**
	 * Instantiates a new message service.
	 *
	 * @param recordProcessor the record processor
	 * @param messageDataSource the message data source
	 */
	public MessageService(IRecordProcessor recordProcessor, IDataSource messageDataSource, ILogService logService) {
		this.recordProcessor = recordProcessor;
		this.messageDataSource = messageDataSource;
		this.logService = logService;
	}

	/**
	 * Save messages.
	 *
	 * @param records the messages
	 * @return true, if successful
	 */
	@Override
	public boolean saveMessages(List<Record> records) {
		LOGGER.trace("Records number: {}", records.size());
		List<Record> transformedRecords = recordProcessor.transformMessage(records);
//		Throws transformed messages to data source
		if (messageDataSource.saveMessages(transformedRecords)) {
			//If save messages is successful, then send log messages as audit messages
			logService.sendAuditMessages(records);
			return true;
		}
		return false;
	}

}
