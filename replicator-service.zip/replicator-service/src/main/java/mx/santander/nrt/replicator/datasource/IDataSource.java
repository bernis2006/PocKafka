/*
 * 
 */
package mx.santander.nrt.replicator.datasource;

import java.util.List;
import mx.santander.nrt.replicator.model.Record;


// IDataSource implementation is responsible to transform the input message
/**
 * The Interface IDataSource.
 */
// to the correct format and send the transformed message to the correct channel.
public interface IDataSource {

	/**
	 * Save messages.
	 *
	 * @param messages the messages
	 * @return true, if successful
	 */
	boolean saveMessages(List<Record> messages);

}
