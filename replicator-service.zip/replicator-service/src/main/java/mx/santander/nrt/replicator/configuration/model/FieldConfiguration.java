/*
 * 
 */
package mx.santander.nrt.replicator.configuration.model;

import java.io.Serializable;


/**
 * The Class FieldConfiguration.
 */
public class FieldConfiguration implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The location. */
	private String location;

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{\"location\":\"" + location + "\"}";
	}

}
