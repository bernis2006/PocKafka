/*
 * 
 */
package mx.santander.nrt.replicator.datasource;

import java.util.List;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.model.Record;


/**
 * The Class OracleDataSource.
 */
public class OracleDataSource implements IDataSource {

	/**
	 * Instantiates a new oracle data source.
	 *
	 * @param configurationProperties the configuration properties
	 */
	public OracleDataSource(IConfigurationProperties configurationProperties) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Save messages.
	 *
	 * @param messages the messages
	 * @return true, if successful
	 */
	@Override
	public boolean saveMessages(List<Record> messages) {
		// TODO Auto-generated method stub
		return false;
	}

}
