/*
 * 
 */
package mx.santander.nrt.replicator.datasource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.client.model.WriteModel;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;
import mx.santander.nrt.replicator.datasource.mongo.processor.MongoPreProcessor;
import mx.santander.nrt.replicator.datasource.mongo.repository.IMongoRepository;
import mx.santander.nrt.replicator.model.Record;


//IDataSource implementation is responsible to transform the input message
/**
 * The Class MongoDataSource.
 */
//to the correct format and send the transformed message to the correct channel.
public class MongoDataSource implements IDataSource {
	
	/** La Constante LOGGER. Obtiene el Logger de la clase. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MongoDataSource.class);

	/** The mongo repository. */
	private final IMongoRepository mongoRepository;
	
	/** The configuration properties. */
	private final IConfigurationProperties configurationProperties;

	/**
	 * Instantiates a new mongo data source.
	 *
	 * @param configurationProperties the configuration properties
	 * @param mongoRepository the mongo repository
	 */
	public MongoDataSource(IConfigurationProperties configurationProperties, IMongoRepository mongoRepository) {
		this.mongoRepository = mongoRepository;
		this.configurationProperties = configurationProperties;
	}

	/**
	 * Save messages.
	 *
	 * @param currentRecords the records
	 * @return true, if successful
	 */
	@Override
	public boolean saveMessages(List<Record> currentRecords) {
		LOGGER.trace("Records number: {}", currentRecords.size());
		// Throws messages to MongoPreProcessor class to transform Objects to
		// WriteModel format
		// and re-throws the transformed message to save with bulkWrite method.
		List<WriteModel<Document>> operations = new ArrayList<WriteModel<Document>>();
		for (Record currentRecord : currentRecords) {
			String tableName = currentRecord.getMetadata().getTableName();
			String operationType = currentRecord.getMetadata().getOperationType();
			ObjectConfig objectConfig = configurationProperties.getObjectConfigByDataSourceAndObjectName("mongo",tableName);
			Map<String, Object> message = currentRecord.getMessage();
			operations.addAll(MongoPreProcessor.transformMessage(objectConfig, message, operationType));
			LOGGER.info("TABLE NAME {}, OPERATIONTYPE {}, OPERATION {}",tableName, operationType, operations.size());
		}
		return mongoRepository.bulkWrite(operations);
	}

}
