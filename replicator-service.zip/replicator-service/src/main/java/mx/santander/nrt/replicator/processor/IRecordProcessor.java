/*
 * 
 */
package mx.santander.nrt.replicator.processor;

import java.util.List;
import mx.santander.nrt.replicator.model.Record;


/**
 * The Interface IRecordProcessor.
 */
public interface IRecordProcessor {
	
	/**
	 * Transform message.
	 *
	 * @param records the records
	 * @return the list
	 */
	List<Record> transformMessage(List<Record> records);
}
