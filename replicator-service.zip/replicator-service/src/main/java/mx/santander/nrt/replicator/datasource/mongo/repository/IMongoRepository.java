/*
 * 
 */
package mx.santander.nrt.replicator.datasource.mongo.repository;

import java.util.List;
import org.bson.Document;
import com.mongodb.client.model.WriteModel;


/**
 * The Interface IMongoDBRepository.
 */
public interface IMongoRepository {

	/**
	 * Metodo que permite realizar un bulkWrite a la coleccion especificada.
	 *
	 * @param documentsToApply
	 *            - Lista de documentos a procesar en el bulkWrite
	 * @return true if all inserts, updates, replaces, and deletes are
	 *         successfully executes
	 */
	boolean bulkWrite(List<WriteModel<Document>> documentsToApply);
}