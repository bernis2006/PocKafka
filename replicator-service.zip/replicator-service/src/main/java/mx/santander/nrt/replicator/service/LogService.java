/*
 * 
 */
package mx.santander.nrt.replicator.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import mx.santander.nrt.replicator.model.Metadata;
import mx.santander.nrt.replicator.model.Record;
import mx.santander.pid.logadapter.core.TrackerGenerator;
import mx.santander.pid.logadapter.core.model.MetadataTracker;
import mx.santander.pid.logadapter.core.types.service.ILogAdapterAuditService;
import mx.santander.pid.logadapter.exception.LogAdapterException;

/**
 * The Class AuditService.
 */
@Service
public class LogService implements ILogService {

	private static final String AUDIT_MESSAGE_BUILD_EXCEPTION = "Audit message build exception";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(LogService.class);

	/** The audit service. */
	private final ILogAdapterAuditService logAdapterAuditService;

	/**
	 * Instantiates a new audit service.
	 *
	 * @param logAdapterAuditService
	 *            the audit service
	 */
	public LogService(ILogAdapterAuditService logAdapterAuditService) {
		this.logAdapterAuditService = logAdapterAuditService;
	}

	/**
	 * Send audit messages.
	 *
	 * @param messages
	 *            the messages to save
	 */
	@Override
	@Async
	public void sendAuditMessages(List<Record> messages) {
		LOGGER.trace("Records number: {}", messages.size());
		MetadataTracker metadataTracker = TrackerGenerator.getMetadataLocalThread();
		// Bitacoriza
		// Resultado: status
		// Codigo: BUC
		// Nombre: TableName
		for (Record message : messages) {
			try {
				Metadata metadata = message.getMetadata();
				logAdapterAuditService.audit(metadata.getOperationType(), metadata.getBuc(),
						metadata.getTableName(), metadataTracker);
			} catch (LogAdapterException e) {
				LOGGER.error(AUDIT_MESSAGE_BUILD_EXCEPTION + ": {} ", e);
			}
		}
	}
}
