/*
 * 
 */
package mx.santander.nrt.replicator.configuration.mapping;

import java.io.Serializable;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import mx.santander.nrt.replicator.configuration.model.DataSourceConfig;
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;
import mx.santander.nrt.replicator.configuration.model.RecordConfiguration;


/**
 * The Class PropertiesMapping.
 */
@Component
@ConfigurationProperties(prefix = "mx.santander.nrt.replicator")
public class PropertiesMapping implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The datasource config. */
	private DataSourceConfig datasourceConfig;

	/** The name mapping. */
	private Map<String, RecordConfiguration> tablesToReplicate;

	/** The object config by datasource. */
	private Map<String, Map<String, ObjectConfig>> objectConfigByDatasource;

	/**
	 * Sets the tables to replicate.
	 *
	 * @param tablesToReplicate the tables to replicate
	 */
	public void setTablesToReplicate(Map<String, RecordConfiguration> tablesToReplicate) {
		this.tablesToReplicate = tablesToReplicate;
	}

	/**
	 * Gets the table to replicate.
	 *
	 * @param tableName the table name
	 * @return the table to replicate
	 */
	public RecordConfiguration getTableToReplicate(String tableName) {
		return tablesToReplicate.get(tableName);
	}

	/**
	 * Gets the datasource config.
	 *
	 * @return the datasource config
	 */
	public DataSourceConfig getDatasourceConfig() {
		return datasourceConfig;
	}

	/**
	 * Sets the datasource config.
	 *
	 * @param datasourceConfig the new datasource config
	 */
	public void setDatasourceConfig(DataSourceConfig datasourceConfig) {
		this.datasourceConfig = datasourceConfig;
	}

	/**
	 * Gets the object config by datasource.
	 *
	 * @param datasource the datasource
	 * @return the object config by datasource
	 */
	public Map<String, ObjectConfig> getObjectConfigByDatasource(String datasource) {
		return objectConfigByDatasource.get(datasource);
	}

	/**
	 * Sets the object config by datasource.
	 *
	 * @param objectConfigByDatasource the object config by datasource
	 */
	public void setObjectConfigByDatasource(Map<String, Map<String, ObjectConfig>> objectConfigByDatasource) {
		this.objectConfigByDatasource = objectConfigByDatasource;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{\"datasourceConfig\":" + datasourceConfig + ", \"tablesToReplicate\":" + tablesToReplicate
				+ ", \"objectConfigByDatasource\":" + objectConfigByDatasource + "}";
	}

}
