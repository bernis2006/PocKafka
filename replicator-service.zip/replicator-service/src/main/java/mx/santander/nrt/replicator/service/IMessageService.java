/*
 * 
 */
package mx.santander.nrt.replicator.service;

import java.util.List;
import mx.santander.nrt.replicator.model.Record;

/**
 * The Interface IMessageService.
 */
public interface IMessageService {

	/**
	 * Save messages.
	 *
	 * @param records the messages
	 * @return true, if successful
	 */
	boolean saveMessages(List<Record> records);
}
