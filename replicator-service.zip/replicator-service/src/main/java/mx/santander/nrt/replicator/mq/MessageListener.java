/*
 * 
 */
package mx.santander.nrt.replicator.mq;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.databind.ObjectMapper;
import mx.santander.nrt.replicator.model.Record;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.model.Key;
import mx.santander.nrt.replicator.service.IMessageService;
//import mx.santander.nrt.monitoring.health.lib.replicator.model.annotation.ProcessingTimeMonitoring


/**
 * The Class ListenerService.
 *
 * @see MessageEvent
 */
@Component
public class MessageListener {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageListener.class);
		
	private static final List<String> VALID_OPERATIONS = Arrays.asList("I","U","R","D"); 
	
	/** The Constant MAPPER. */
	private static final ObjectMapper MAPPER = new ObjectMapper();

	/** The context. */
	private final IMessageService messageService;
	
	/** The configuration properties. */
	private final IConfigurationProperties configurationProperties;

	/**
	 * Instantiates a new listener service.
	 *
	 * @param messageService the message service
	 * @param configurationProperties the configuration properties
	 */
	public MessageListener(IMessageService messageService, IConfigurationProperties configurationProperties) {
		this.messageService = messageService;
		this.configurationProperties = configurationProperties;
	}

	/**
	 * Save messages.
	 *
	 * @param currentRecords the current records
	 */
	@KafkaListener(topics = "${spring.kafka.consumer.topics.customers}")
//	@ProcessingTimeMonitoring(fuentes = "PEDT001,PEDT150,TWDTACU,TCL05_DATOSWEB,ODDTUTC,ODDTUCE,PEDT115,PEDT023", origenes = "nrt_enr_rpt_customers_me", destinos = "rpt_customers_me", flujoReplicacion = "customerMe", informacionAdicional = "Data for consumer me replicator")
	public void saveMessages(List<ConsumerRecord<String, String>> currentRecords) {
		LOGGER.trace("Records number: {}", currentRecords.size());
		List<Record> mappedMessages = new ArrayList<Record>();
		for (ConsumerRecord<String, String> currentRecord : currentRecords) {
			try {
				validateMessage(mappedMessages, currentRecord);
			} catch (JacksonException e) {
				String msj = "Invalid Message. Partition: " + currentRecord.partition() + ", OffSet: "
						+ currentRecord.offset();
				LOGGER.error(msj + ": {} ", e);
				// TODO: Send message to "Invalid message queue"
			}
		}
		
		if (!mappedMessages.isEmpty()) {
			messageService.saveMessages(mappedMessages);
			// TODO: if save message is not successful, then:
			// TODO: Send message to "Save later queue"
		}
	}

	/**
	 * Validate message.
	 *
	 * @param mappedMessages the mapped messages
	 * @param currentRecord the current record
	 * @throws JacksonException the jackson exception
	 */
	private void validateMessage(List<Record> mappedMessages, ConsumerRecord<String, String> currentRecord) throws JacksonException {
		if (currentRecord != null && currentRecord.value() != null) {
			Record tmpRecord = MAPPER.readValue(currentRecord.value(), Record.class);
			if (isValidDataAndMetadataValue(tmpRecord) && isValidKeyValue(currentRecord, tmpRecord)) {
				mappedMessages.add(tmpRecord);
			} else {
				LOGGER.error("Validate message structure. Partition: " + currentRecord.partition() + ", OffSet: "
						+ currentRecord.offset());
			}
		} else {
			LOGGER.error("Invalid null message");
		}
	}

	/**
	 * Checks if is valid key value.
	 *
	 * @param currentRecord the current record
	 * @param record the record
	 * @return true, if is valid key value
	 * @throws JacksonException the jackson exception
	 */
	private boolean isValidKeyValue(ConsumerRecord<String, String> currentRecord,
			Record record) throws JacksonException {
		if (currentRecord.key() != null) {
			Key key = MAPPER.readValue(currentRecord.key(), Key.class);
			if (key != null && key.getBuc() != null && !key.getBuc().trim().isEmpty()) {
				record.getMetadata().setBuc(key.getBuc());
				return true;
			} else {
				LOGGER.error("Invalid message, invalid key value");
				// TODO: Send message to "Invalid message queue"
			}
		} else {
			LOGGER.error("Key not found or null");
			// TODO: Send message to "Invalid message queue"
		}
		return false;
	}


	/**
	 * Checks if is valid data and metadata value.
	 *
	 * @param record the record
	 * @return true, if is valid data and metadata value, if is not null, empty or invalid
	 */
	private boolean isValidDataAndMetadataValue(Record record) {
		boolean isValid = true;
		// Validate metadata
		if (record.getMetadata() != null) {
			LOGGER.trace("Metadata in message is not null");
			// Validate tableName and operationType
			String tableName = record.getMetadata().getTableName();
			String operationType = record.getMetadata().getOperationType();
			if (tableName != null && !tableName.trim().isEmpty() &&  operationType != null && !operationType.trim().isEmpty()) {
				LOGGER.trace("TableName and OperationType in metadata is not null");
				//Validate implementation (table name)
				boolean isValidTableName = validateTableName(tableName);
				//Validate operation type			
				boolean isValidOperationType = validateOperationType(operationType);
				if (isValidTableName && isValidOperationType) {
					LOGGER.trace("TableName and OperationType value is valid");
				} else {
					LOGGER.error("TableName or OperationType value is not valid");
					// TODO: Send message to "Invalid message queue"
					isValid = false;
				}
			} else {
				LOGGER.error("Invalid message, null tableName or operationType");
				// TODO: Send message to "Invalid message queue"
				isValid = false;	
			}
		} else {
			LOGGER.error("Invalid message, metadata not found or null");
			// TODO: Send message to "Invalid message queue"
			isValid = false;
		}
		// Validate data
		if (record.getData() != null && !record.getData().isEmpty()) {
			LOGGER.trace("Data in message is not empty");
		} else {
			LOGGER.error("Invalid message, data not found or null");
			// TODO: Send message to "Invalid message queue"
			isValid = false;
		}
		return isValid;
	}

	/**
	 * Validate operation type.
	 *
	 * @param operationType the operation type
	 * @return true, if operation type is valid operation
	 */
	private boolean validateOperationType(String operationType) {
		if (VALID_OPERATIONS.contains(operationType)) {
			return true;
		}
		return false;
	}

	/**
	 * Validate table name.
	 *
	 * @param tableName the table name
	 * @return true, if table name is implemented
	 */
	private boolean validateTableName(String tableName) {
		if (configurationProperties.getTableToReplicate(tableName) != null) {
			return true;
		}
		return false;
	}
}