/*
 * 
 */
package mx.santander.nrt.replicator.configuration.model;

import java.io.Serializable;
import java.util.Map;


/**
 * The Class DataSourceConfig.
 */
public class DataSourceConfig implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The default data source. */
	private String defaultDataSource;

	/** The channels. */
	private Map<String, Channel> channels;

	/**
	 * Gets the default data source.
	 *
	 * @return the default data source
	 */
	public String getDefaultDataSource() {
		return defaultDataSource;
	}

	/**
	 * Sets the default data source.
	 *
	 * @param defaultDataSource the new default data source
	 */
	public void setDefaultDataSource(String defaultDataSource) {
		this.defaultDataSource = defaultDataSource;
	}

	/**
	 * Gets the channels.
	 *
	 * @return the channels
	 */
	public Map<String, Channel> getChannels() {
		return channels;
	}

	/**
	 * Sets the channels.
	 *
	 * @param channels the channels
	 */
	public void setChannels(Map<String, Channel> channels) {
		this.channels = channels;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{\"defaultDataSource\":\"" + defaultDataSource + "\", \"channels\":" + channels + "}";
	}

}
