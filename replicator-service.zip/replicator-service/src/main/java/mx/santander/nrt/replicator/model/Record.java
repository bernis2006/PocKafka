/*
 * 
 */
package mx.santander.nrt.replicator.model;

import java.io.Serializable;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The Class Message.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Record implements Serializable {

	/** Id de serializacion. */
	private static final long serialVersionUID = 1L;

	/** Metadatos del mensaje del topico Kafka. */
	private Metadata metadata;

	/** The data. */
	private Map<String, String> data;

	/** The message. */
	private Map<String, Object> message;

	/**
	 * Instantiates a new message.
	 */
	public Record() {
		// Auto-generated constructor stub
	}

	/**
	 * Instantiates a new record.
	 *
	 * @param metadata the metadata
	 * @param message the message
	 */
	public Record(Metadata metadata, Map<String, Object> message) {
		this.metadata = metadata;
		this.message = message;
	}

	/**
	 * Gets the metadata.
	 *
	 * @return the metadata
	 */
	public Metadata getMetadata() {
		return metadata;
	}

	/**
	 * Sets the metadata.
	 *
	 * @param metadata the new metadata
	 */
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

	/**
	 * Gets the data.
	 *
	 * @return the data
	 */
	public Map<String, String> getData() {
		return data;
	}

	/**
	 * Sets the data.
	 *
	 * @param data the data
	 */
	@JsonAnySetter
	public void setData(Map<String, String> data) {
		this.data = data;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public Map<String, Object> getMessage() {
		return message;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{\"metadata\":" + metadata + ", \"data\":" + data + ", \"message\":" + message + "}";
	}

}