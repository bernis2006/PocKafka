/*
 * 
 */
package mx.santander.nrt.replicator.configuration.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * The Class ObjectConfig.
 */
public class ObjectConfig implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The primary filter. */
	private String primaryFilter;

	/** The secondary filters. */
	private List<String> secondaryFilters;

	/** The object type config. */
	private Map<String, String> objectTypeConfig;

	/**
	 * Gets the primary filter.
	 *
	 * @return the primary filter
	 */
	public String getPrimaryFilter() {
		return primaryFilter;
	}

	/**
	 * Sets the primary filter.
	 *
	 * @param primaryFilter the new primary filter
	 */
	public void setPrimaryFilter(String primaryFilter) {
		this.primaryFilter = primaryFilter;
	}

	/**
	 * Gets the secondary filters.
	 *
	 * @return the secondary filters
	 */
	public List<String> getSecondaryFilters() {
		return secondaryFilters;
	}

	/**
	 * Sets the secondary filters.
	 *
	 * @param secondaryFilters the new secondary filters
	 */
	public void setSecondaryFilters(List<String> secondaryFilters) {
		this.secondaryFilters = secondaryFilters;
	}

	/**
	 * Checks if is collection element.
	 *
	 * @return true, if secondaryFilters list contains elements.
	 */
	public boolean isCollectionElement() {
		if (secondaryFilters != null) {
			return !secondaryFilters.isEmpty();
		}
		return false;
	}

	/**
	 * Gets the object type config.
	 *
	 * @return the object type config
	 */
	public Map<String, String> getObjectTypeConfig() {
		return objectTypeConfig;
	}

	/**
	 * Sets the object type config.
	 *
	 * @param objectTypeConfig the object type config
	 */
	public void setObjectTypeConfig(Map<String, String> objectTypeConfig) {
		this.objectTypeConfig = objectTypeConfig;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "{\"isCollectionElement\":" + isCollectionElement() + ", \"primaryFilter\":\"" + primaryFilter
				+ "\", \"secondaryFilters\":" + secondaryFilters + ", \"objectTypeConfig\":" + objectTypeConfig + "}";
	}

}
