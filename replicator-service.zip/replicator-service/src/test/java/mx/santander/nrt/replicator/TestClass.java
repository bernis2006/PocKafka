package mx.santander.nrt.replicator;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class TestClass {
	
	@Test
	void MainTest() {
		Map<String, String> test = new HashMap<String, String>();
		test.putAll(test1());
		test.forEach((k,v) -> {
			System.out.println(k);	
		});
	}

	Map<String, String> test1() {
		Map<String, String> test = new HashMap<String, String>();
		test.put("mx-opsexec-spec-conssrvcs-tax-cfdi-pro.cfdi-validacion-service cfdi-validacion-service", "");
		test.put("mx-baas-orchestation-pro.mx-baas-orchestation-pro-offers-preclass-service -CLICKTOSELL-LOGSERVICE", "");
		test.put("mx-baas-orchestation-pro.mx-baas-orchestation-pro-offers-preclass-service -CLICKTOSELL-LOGSERVICE", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion DESCONOCIDO", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion DESCONOCIDO", "");
		test.put("mx-opsexec-spec-conssrvcs-tax-cfdi-pro.cfdi-validacion-service cfdi-validacion-service", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-validacion sesionaplicativa-servicios-validacion", "");
		test.put("mxservcorebiom-pro.bio-record-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion sesionaplicativa-servicios-sesion", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion DESCONOCIDO", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-logout sesionaplicativa-servicios-logout", "");
		test.put("mxservcorebiom-pro.consulta-bajas-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-validacion INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-logout INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-validacion sesionaplicativa-servicios-validacion", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-logout sesionaplicativa-servicios-logout", "");
		test.put("mxservcorebiom-pro.consultadj-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-logout sesionaplicativa-servicios-logout", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.consulta-enroll-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mx-baas-orchestation-pro.ou-or-customer-onboarding-tdc DESCONOCIDO", "");
		test.put("mxservcorebiom-pro.consultas-trx-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-validacion sesionaplicativa-servicios-validacion ", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-validacion INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-validacion INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.consulta-bajas-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-logout INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.consultas-trx-service INTRAMX-APPEB-SSOWCBIOMETRICOS", "");
		test.put("mxservcorebiom-pro.sesionaplicativa-servicios-sesion sesionaplicativa-servicios-sesion", "");
		return test;
	}


}
