package mx.santander.nrt.replicator.datasource.mongo.repository;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import com.mongodb.MongoBulkWriteException;
import com.mongodb.bulk.BulkWriteError;
import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.WriteModel;

class MongoRepositoryTests {
	
	@Test
	void bulkWriteTest() {
		MongoCollection<Document> collection = Mockito.mock(MongoCollection.class);
		BulkWriteResult value = Mockito.mock(BulkWriteResult.class);
		Mockito.when(collection.bulkWrite(Mockito.anyList(), Mockito.any())).thenReturn(value);
		
		IMongoRepository mongoRepository = new MongoRepository(collection);
		List<WriteModel<Document>> documentsToAppy = new ArrayList<WriteModel<Document>>();
		boolean response = mongoRepository.bulkWrite(documentsToAppy);
		assertThat(response).isTrue();
	}
	
	@Test
	void bulkWriteExceptionTest() {
		MongoCollection<Document> collection = Mockito.mock(MongoCollection.class);
		BulkWriteResult value = Mockito.mock(BulkWriteResult.class);
		
		MongoBulkWriteException bulkWriteException = Mockito.mock(MongoBulkWriteException.class);
		Mockito.when(bulkWriteException.getWriteResult()).thenReturn(value);
		List<BulkWriteError> writeErrors = new ArrayList<BulkWriteError>();
		Mockito.when(bulkWriteException.getWriteErrors()).thenReturn(writeErrors);
	
		
		Mockito.when(collection.bulkWrite(Mockito.anyList(), Mockito.any())).thenThrow(bulkWriteException);
		
		IMongoRepository mongoRepository = new MongoRepository(collection);
		List<WriteModel<Document>> documentsToAppy = new ArrayList<WriteModel<Document>>();
		boolean response = mongoRepository.bulkWrite(documentsToAppy);
		assertThat(response).isFalse();
	}

}
