package mx.santander.nrt.replicator.service;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import mx.santander.nrt.replicator.model.Metadata;
import mx.santander.nrt.replicator.model.Record;
import mx.santander.pid.logadapter.core.model.MetadataTracker;
import mx.santander.pid.logadapter.core.types.service.ILogAdapterAuditService;
import mx.santander.pid.logadapter.exception.LogAdapterException;

class LogServiceTests {
	
	@Test
	void sendAuditMessagesTest() throws LogAdapterException {
		ILogAdapterAuditService logAdapterAuditService = Mockito.mock(ILogAdapterAuditService.class);
		Mockito.doThrow(new LogAdapterException("", "")).when(logAdapterAuditService).audit(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(MetadataTracker.class));
		ILogService logService = new LogService(logAdapterAuditService);		
		List<Record> messages = new ArrayList<Record>();
		Record record = new Record();
		Metadata metadata = new Metadata();
		metadata.setBuc("");
		metadata.setOperationType("");
		metadata.setTableName("");
		record.setMetadata(metadata);
		messages.add(record);
		logService.sendAuditMessages(messages);
		
		try {
			Mockito.doThrow(new LogAdapterException("", "")).when(logAdapterAuditService).audit(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(MetadataTracker.class));
			MetadataTracker metadataTracker = new MetadataTracker();
			logAdapterAuditService.audit("", "", "", metadataTracker);	
		} catch (LogAdapterException e) {
			assertThat(e).isExactlyInstanceOf(LogAdapterException.class);
		}

	}
}
