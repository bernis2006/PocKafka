package mx.santander.nrt.replicator.service;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.databind.ObjectMapper;
import mx.santander.nrt.replicator.datasource.IDataSource;
import mx.santander.nrt.replicator.model.Record;
import mx.santander.nrt.replicator.processor.IRecordProcessor;
import mx.santander.pid.logadapter.core.model.MetadataTracker;
import mx.santander.pid.logadapter.core.types.service.ILogAdapterAuditService;
import mx.santander.pid.logadapter.exception.LogAdapterException;

class MessageServiceTests {
	
	@Test
	void saveMessagesTest() throws JacksonException, LogAdapterException {
		String data = "{\"PEPRIAPE\": \"DOMINGUEZ \",\"PESEGAPE\": \"DIAZ \",\"PENOMPER\": \"MICHEL GUADALUPE \",\"PETIPPER\": \"F\",\"PEINDNO1\": \"N\",\"PEINDNO2\": \"1\",\"PEARENEG\": \"007\",\"PEESTPER\": \"010\",\"PECONPER\": \"CLI\",\"PEFECNAC\": \"1997-05-01\",\"PEFECINI\": \"0001-01-01\",\"PEESTCIV\": \"S\",\"PESEXPER\": \"M\",\"PESUCADM\": \"7801\",\"PECANCAP\": \"022\",\"PEPAIORI\": \"056\",\"PENACPER\": \"056\",\"PEPAIRES\": \"056\",\"PESECPER\": \"013\",\"PETIPOCU\": \"  \",\"PECODACT\": \"01330001\",\"PETIERES\": \"0\",\"PEFORJUR\": \"  \",\"PENATJUR\": \"   \",\"PECODSUJ\": \"442\",\"PEBANPRI\": \" \",\"PEHSTAMP\": \"2021-12-02 14:09:21\",\"PECDGENT\": \"0014\",\"buc\": \"00000000\"}",
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\": \"I\",\"commit_cycle_id\": \"1910576510379032576\",\"table_name\": \"PEDT001\",\"operation_utc_ts\": \"2022-01-13 20:08:19.417000000000\",\"operation_ts\": \"2022-01-13 14:08:19.417000000000\",\"transform_ts\": \"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";		
		List<Record> messages = new ArrayList<Record>();
		messages.add(new ObjectMapper().readValue(message, Record.class));
		
		IRecordProcessor recordProcessor = Mockito.mock(IRecordProcessor.class);
		Mockito.when(recordProcessor.transformMessage(Mockito.anyList())).thenReturn(messages);
		IDataSource messageDataSource  = Mockito.mock(IDataSource.class);
		Mockito.when(messageDataSource.saveMessages(Mockito.anyList())).thenReturn(true);
		
		ILogAdapterAuditService logAdapterAuditService = Mockito.mock(ILogAdapterAuditService.class);
		ILogService logService = new LogService(logAdapterAuditService); 
		
		IMessageService messageService = new MessageService(recordProcessor, messageDataSource, logService);
		messageService.saveMessages(messages);
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageDataSource).saveMessages(messagesCaptor.capture());
		List<Record> expectedMessages = messagesCaptor.getValue();
		
		assertThat(expectedMessages).usingRecursiveComparison().isEqualTo(messages);
		
		ArgumentCaptor<String> operationTypeCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> bucCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> tableNameCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<MetadataTracker> metadataTrackerCaptor = ArgumentCaptor.forClass(MetadataTracker.class);
		
		Mockito.verify(logAdapterAuditService).audit(operationTypeCaptor.capture(), bucCaptor.capture(), tableNameCaptor.capture(), metadataTrackerCaptor.capture());
		assertThat(operationTypeCaptor.getValue()).isEqualTo("I");
		assertThat(bucCaptor.getValue()).isEqualTo("00000875");
		assertThat(tableNameCaptor.getValue()).isEqualTo("PEDT001");
	}
	
	@Test
	void noSaveMessagesTest() throws JacksonException, LogAdapterException {
		List<Record> messages = new ArrayList<Record>();
		IRecordProcessor recordProcessor = Mockito.mock(IRecordProcessor.class);
		IDataSource messageDataSource  = Mockito.mock(IDataSource.class);
		Mockito.when(messageDataSource.saveMessages(Mockito.anyList())).thenReturn(false);
		
		ILogAdapterAuditService logAdapterAuditService = Mockito.mock(ILogAdapterAuditService.class);
		ILogService logService = new LogService(logAdapterAuditService); 
		
		IMessageService messageService = new MessageService(recordProcessor, messageDataSource, logService);
		boolean saveMessageStatus = messageService.saveMessages(messages);
		
		assertThat(saveMessageStatus).isFalse();
	}
}