package mx.santander.nrt.replicator.datasource;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonFactoryBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOneModel;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.WriteModel;
import mx.santander.nrt.replicator.configuration.ConfigurationProperties;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.mapping.PropertiesMapping;
import mx.santander.nrt.replicator.configuration.model.ObjectConfig;
import mx.santander.nrt.replicator.datasource.mongo.repository.IMongoRepository;
import mx.santander.nrt.replicator.datasource.mongo.repository.MongoRepository;
import mx.santander.nrt.replicator.model.Record;
import static com.mongodb.client.model.Updates.pull;
import static com.mongodb.client.model.Updates.push;

class MongoDataSourceTests {
	
	@Test
	void saveMessagesTests() throws JacksonException {
		Map<String, Map<String, ObjectConfig>> objectConfigByDatasource = getObjectConfigByDatasource();
		PropertiesMapping propertiesMapping = new PropertiesMapping();
		propertiesMapping.setObjectConfigByDatasource(objectConfigByDatasource);
		
		Map<String, ObjectConfig> mongoConfig = propertiesMapping.getObjectConfigByDatasource("mongo");
		ObjectConfig pedt001ObjectConfig = mongoConfig.get("PEDT001");
		pedt001ObjectConfig.toString();
		
		IConfigurationProperties configurationProperties = new ConfigurationProperties(propertiesMapping);
		
		IMongoRepository mongoRepository = Mockito.mock(MongoRepository.class);
		IDataSource dataSource = new MongoDataSource(configurationProperties, mongoRepository);
		
		List<Record> messages = getMessages();
		dataSource.saveMessages(messages);
		
		ArgumentCaptor<List<WriteModel<Document>>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(mongoRepository).bulkWrite(messagesCaptor.capture());
		List<WriteModel<Document>> writeModelMessages = messagesCaptor.getValue();

		assertThat(writeModelMessages.size()).isEqualTo(7);		
		List<WriteModel<Document>> expectedWriteModelMessages = getExpectedWriteModelObject();
		int i = 0;
		for (WriteModel<Document> writeModel: writeModelMessages) {
			assertThat(writeModel.toString()).hasToString(expectedWriteModelMessages.get(i).toString());
			i++;
		}
		
	}

	private Map<String, Map<String, ObjectConfig>> getObjectConfigByDatasource() throws JacksonException {
		String config = "{"
				+ "	\"mongo\": {"
				+ "		\"PEDT001\": {"
				+ "			\"primaryFilter\": \"partyId\","
				+ "			\"objectTypeConfig\": {"
				+ "				\"partyInfo.personPartyInfo.birthDt\": \"date\","
				+ "				\"partyInfo.establishedDt\": \"date\","
				+ "				\"partyEnvr.lastUpdateDt\": \"timestamp\""
				+ "			}"
				+ "		},"
				+ "		\"ALGO\": {"
				+ "			\"primaryFilter\": \"string\","
				+ "			\"objectTypeConfig\": {"
				+ "				\"int\": \"int\","
				+ "				\"long\": \"long\","
				+ "				\"double\": \"double\""
				+ "			}"
				+ "		},"
				+ "		\"ALGO2\": {"
				+ "			\"primaryFilter\": \"string\","
				+ "			\"objectTypeConfig\": {"
				+ "				\"object1.object2.object3.object4.int\": \"int\","
				+ "				\"object1.object2.object3.object4.long\": \"long\","
				+ "				\"object1.object2.object3.object4.double\": \"double\""
				+ "			},"
				+ "			\"secondaryFilters\": ["
				+ "				\"object1.object2.object3.int\""
				+ "			]"
				+ "		}"
				+ "	}"
				+ "}";
		return new ObjectMapper().readValue(config, new TypeReference<Map<String, Map<String, ObjectConfig>>>(){});
	}

	private List<Record> getMessages() throws JacksonException {
		String message = "["
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"PEDT001\", "
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\", "
				+ "			\"commit_cycle_id\":1910576510379032576, "
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\", "
				+ "			\"operation_type\":\"R\", "
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		}, "
				+ "		\"data\":null, "
				+ "		\"message\":{"
				+ "			\"partyStatus\":{"
				+ "				\"partyAdditionalStatusCode\":\"010\","
				+ "				\"partyStatusCode\":\"CLI\""
				+ "			},"
				+ "			\"partyInfo\":{"
				+ "				\"residenceCountry\":{"
				+ "					\"countryCodeValue\":\"056\","
				+ "					\"timeFrame\":{"
				+ "						\"duration\":{"
				+ "							\"count\":\"0\""
				+ "						}"
				+ "					}"
				+ "				},"
				+ "				\"peindno1\":\"N\","
				+ "				\"originatingChannelCode\":\"022\","
				+ "				\"serviceLevelCode\":\"007\","
				+ "				\"personPartyInfo\":{"
				+ "					\"personName\":{"
				+ "						\"paternalName\":\"DOMINGUEZ \","
				+ "						\"maternalName\":\"DIAZ \","
				+ "						\"givenName\":\"MICHEL GUADALUPE \""
				+ "					},"
				+ "					\"birthDt\":\"1997-05-01\","
				+ "					\"maritalStat\":\"S\","
				+ "					\"gender\":\"M\","
				+ "					\"originatingBranchCode\":\"7801\""
				+ "				},"
				+ "				\"accountingField\":\"442\","
				+ "				\"legalEntity\":\"   \","
				+ "				\"establishedDt\":\"0001-01-01\","
				+ "				\"customerType\":\"F\","
				+ "				\"orgPartyInfo\":{"
				+ "					\"legalForm\":\"  \""
				+ "				},"
				+ "				\"birthCountry\":{"
				+ "					\"countryCodeValue\":\"056\""
				+ "				},"
				+ "				\"occupationData\":{"
				+ "					\"genericActivityCode\":\"013\","
				+ "					\"occupationCode\":\"  \","
				+ "					\"specificActivityCode\":\"01330001\""
				+ "				},"
				+ "				\"fiscalActivityInd\":\"1\","
				+ "				\"privateBankingInd\":\" \","
				+ "				\"entity\":\"0014\","
				+ "				\"nationalityCountry\":{"
				+ "					\"countryCodeValue\":\"056\""
				+ "				}"
				+ "			},"
				+ "			\"partyId\":\"00000875\","
				+ "			\"partyEnvr\":{"
				+ "				\"lastUpdateDt\":\"2021-12-02 14:09:21\""
				+ "			}"
				+ "		}"
				+ "	},"
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"ALGO\", "
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\", "
				+ "			\"commit_cycle_id\":1910576510379032576, "
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\", "
				+ "			\"operation_type\":\"R\", "
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		}, "
				+ "		\"data\":null, "
				+ "		\"message\":{"
				+ "			\"string\": \"algo1\","
				+ "			\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "			\"date\": \"2022-06-27\","
				+ "			\"int\": \"2147483647\","
				+ "			\"long\": \"9223372036854775807\","
				+ "			\"double\": \"3.13457599923384753929348D\","
				+ "			\"object\": {"
				+ "				\"string\": \"algo2\""
				+ "			},"
				+ "			\"object2\": {"
				+ "				\"object\" : {"
				+ "					\"string\": \"algo3\""
				+ "				}"
				+ "			},"
				+ "			\"object3\": {"
				+ "				\"string\": \"algo4\","
				+ "				\"object\" : {"
				+ "					\"string\": \"algo5\""
				+ "				}"
				+ "			},"
				+ "			\"object4\": {"
				+ "				\"string\": \"algo6\","
				+ "				\"string2\": \"algo7\","
				+ "				\"object\" : {"
				+ "					\"string\": \"algo8\""
				+ "				},"
				+ "				\"object2\" : {"
				+ "					\"string\": \"algo9\","
				+ "					\"string2\": \"algo10\""
				+ "				}"
				+ "			}"
				+ "		}"
				+ "	},"
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"ALGO2\","
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\","
				+ "			\"commit_cycle_id\":1910576510379032576,"
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\","
				+ "			\"operation_type\":\"R\","
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		},"
				+ "		\"data\":null,"
				+ "		\"message\":{"
				+ "			\"string\": \"algo1\","
				+ "			\"object1\": {"
				+ "				\"object2\" : {"
				+ "					\"object3\" : {"
				+ "						\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "						\"date\": \"2022-06-27\","
				+ "						\"int\": \"2147483647\","
				+ "						\"long\": \"9223372036854775807\","
				+ "						\"double\": \"3.13457599923384753929348D\","
				+ "						\"object4\" : {"
				+ "							\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "							\"date\": \"2022-06-27\","
				+ "							\"int\": \"2147483647\","
				+ "							\"long\": \"9223372036854775807\","
				+ "							\"double\": \"3.13457599923384753929348D\""
				+ "						}"
				+ "					}"
				+ "				}"
				+ "			}"
				+ "		}"
				+ "	},"
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"ALGO\", "
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\", "
				+ "			\"commit_cycle_id\":1910576510379032576, "
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\", "
				+ "			\"operation_type\":\"D\", "
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		}, "
				+ "		\"data\":null, "
				+ "		\"message\":{"
				+ "			\"string\": \"algo1\","
				+ "			\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "			\"date\": \"2022-06-27\","
				+ "			\"int\": \"2147483647\","
				+ "			\"long\": \"9223372036854775807\","
				+ "			\"double\": \"3.13457599923384753929348D\","
				+ "			\"object\": {"
				+ "				\"string\": \"algo2\""
				+ "			},"
				+ "			\"object2\": {"
				+ "				\"object\" : {"
				+ "					\"string\": \"algo3\""
				+ "				}"
				+ "			},"
				+ "			\"object3\": {"
				+ "				\"string\": \"algo4\","
				+ "				\"object\" : {"
				+ "					\"string\": \"algo5\""
				+ "				}"
				+ "			},"
				+ "			\"object4\": {"
				+ "				\"string\": \"algo6\","
				+ "				\"string2\": \"algo7\","
				+ "				\"object\" : {"
				+ "					\"string\": \"algo8\""
				+ "				},"
				+ "				\"object2\" : {"
				+ "					\"string\": \"algo9\","
				+ "					\"string2\": \"algo10\""
				+ "				}"
				+ "			}"
				+ "		}"
				+ "	},"
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"ALGO2\","
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\","
				+ "			\"commit_cycle_id\":1910576510379032576,"
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\","
				+ "			\"operation_type\":\"D\","
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		},"
				+ "		\"data\":null,"
				+ "		\"message\":{"
				+ "			\"string\": \"algo1\","
				+ "			\"object1\": {"
				+ "				\"object2\" : {"
				+ "					\"object3\" : {"
				+ "						\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "						\"date\": \"2022-06-27\","
				+ "						\"int\": \"2147483647\","
				+ "						\"long\": \"9223372036854775807\","
				+ "						\"double\": \"3.13457599923384753929348D\","
				+ "						\"object4\" : {"
				+ "							\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "							\"date\": \"2022-06-27\","
				+ "							\"int\": \"2147483647\","
				+ "							\"long\": \"9223372036854775807\","
				+ "							\"double\": \"3.13457599923384753929348D\""
				+ "						}"
				+ "					}"
				+ "				}"
				+ "			}"
				+ "		}"
				+ "	}"
				+ "]";
		return new ObjectMapper().readValue(message, new TypeReference<List<Record>>(){});
	}
	
	private List<WriteModel<Document>> getExpectedWriteModelObject() throws JsonMappingException, JsonProcessingException {
		JsonFactoryBuilder jfb = new JsonFactoryBuilder();
		jfb.enable(JsonReadFeature.ALLOW_LEADING_ZEROS_FOR_NUMBERS);
		ObjectMapper objectMapper = new ObjectMapper(jfb.build());
		List<WriteModel<Document>> writeModelMessages = new ArrayList<WriteModel<Document>>();
		// PEDT001 SET
		String updates = "{"
				+ "	\"partyInfo.residenceCountry.timeFrame.duration.count\":\"0\","
				+ "	\"partyInfo.occupationData.genericActivityCode\":\"013\","
				+ "	\"partyInfo.personPartyInfo.personName.givenName\":\"MICHEL GUADALUPE \","
				+ "	\"partyInfo.personPartyInfo.gender\":\"M\","
				+ "	\"partyInfo.privateBankingInd\":\" \","
				+ "	\"partyInfo.establishedDt\": \"0001-01-01\","
				+ "	\"partyInfo.orgPartyInfo.legalForm\":\"  \","
				+ "	\"partyInfo.serviceLevelCode\":\"007\","
				+ "	\"partyInfo.personPartyInfo.maritalStat\":\"S\","
				+ "	\"partyId\":\"00000875\","
				+ "	\"partyInfo.peindno1\":\"N\","
				+ "	\"partyInfo.personPartyInfo.birthDt\": \"1997-05-01\","
				+ "	\"partyStatus.partyAdditionalStatusCode\":\"010\","
				+ "	\"partyInfo.customerType\":\"F\","
				+ "	\"partyStatus.partyStatusCode\":\"CLI\","
				+ "	\"partyInfo.originatingChannelCode\":\"022\","
				+ "	\"partyInfo.fiscalActivityInd\":\"1\","
				+ "	\"partyInfo.entity\":\"0014\","
				+ "	\"partyInfo.legalEntity\":\"   \","
				+ "	\"partyInfo.personPartyInfo.personName.maternalName\":\"DIAZ \","
				+ "	\"partyInfo.nationalityCountry.countryCodeValue\":\"056\","
				+ "	\"partyInfo.occupationData.specificActivityCode\":\"01330001\","
				+ "	\"partyEnvr.lastUpdateDt\": \"2021-12-02 14:09:21.0\","
				+ "	\"partyInfo.residenceCountry.countryCodeValue\":\"056\","
				+ "	\"partyInfo.birthCountry.countryCodeValue\":\"056\","
				+ "	\"partyInfo.occupationData.occupationCode\":\"  \","
				+ "	\"partyInfo.personPartyInfo.originatingBranchCode\":\"7801\","
				+ "	\"partyInfo.personPartyInfo.personName.paternalName\":\"DOMINGUEZ \","
				+ "	\"partyInfo.accountingField\":\"442\""
				+ "}";
		UpdateOneModel<Document> model = new UpdateOneModel<Document>(Filters.eq("partyId","00000875").toBsonDocument(), new Document("$set", objectMapper.readValue(updates, new TypeReference<Map<String, Object>>(){})), new UpdateOptions().upsert(true));
		writeModelMessages.add(model);
		// ALGO SET
		updates = "{"
				+ "	\"date\":\"2022-06-27\","
				+ "	\"object4.object.string\":\"algo8\","
				+ "	\"string\":\"algo1\","
				+ "	\"object4.string2\":\"algo7\","
				+ "	\"double\":\"3.1345759992338476\","
				+ "	\"object2.object.string\":\"algo3\","
				+ "	\"object3.object.string\":\"algo5\","
				+ "	\"int\":\"2147483647\","
				+ "	\"long\":\"9223372036854775807\","
				+ "	\"object4.object2.string\":\"algo9\","
				+ "	\"object.string\":\"algo2\","
				+ "	\"object4.object2.string2\":\"algo10\","
				+ "	\"object4.string\":\"algo6\","
				+ "	\"timestamp\":\"2022-06-27 12:09:12.000\","
				+ "	\"object3.string\":\"algo4\""
				+ "}";
		model = new UpdateOneModel<Document>(Filters.eq("string", "algo1").toBsonDocument(), new Document("$set", objectMapper.readValue(updates, new TypeReference<Map<String, String>>(){})), new UpdateOptions().upsert(true));
		writeModelMessages.add(model);
		// ALGO2 SET
		model = new UpdateOneModel<Document>(Filters.eq("string", "algo1").toBsonDocument(), new Document("$set", "{\"string\": \"algo1\"}"), new UpdateOptions().upsert(true));
		writeModelMessages.add(model);
		// ALGO2 PULL
		updates = "{"
				+ "	\"int\":\"2147483647\""
				+ "}";
		model = new UpdateOneModel<Document>(Filters.and(Filters.eq("string", "algo1"),Filters.eq("object1.object2.object3.int", "2147483647")), pull("object1.object2.object3", objectMapper.readValue(updates, new TypeReference<Map<String, String>>(){})));
		writeModelMessages.add(model);
		// ALGO2 PUSH
		updates = "{"
				+ "	\"date\":\"2022-06-27\","
				+ "	\"object4.date\":\"2022-06-27\","
				+ "	\"object4.double\":\"3.1345759992338476\","
				+ "	\"double\":\"3.13457599923384753929348D\","
				+ "	\"object4.int\":\"2147483647\","
				+ "	\"object4.long\":\"9223372036854775807\","
				+ "	\"int\":\"2147483647\","
				+ "	\"long\":\"9223372036854775807\","
				+ "	\"timestamp\":\"2022-06-27 12:09:12.000\","
				+ "	\"object4.timestamp\":\"2022-06-27 12:09:12.000\""
				+ "}";
		model = new UpdateOneModel<Document>(Filters.eq("string", "algo1").toBsonDocument(), push("object1.object2.object3", objectMapper.readValue(updates, new TypeReference<Map<String, String>>(){})));
		writeModelMessages.add(model);
		// ALGO D
		updates = "{"
				+ "	\"date\":\"2022-06-27\","
				+ "	\"object4.object.string\":\"algo8\","
				+ "	\"object4.string2\":\"algo7\","
				+ "	\"double\":\"3.1345759992338476\","
				+ "	\"object2.object.string\":\"algo3\","
				+ "	\"object3.object.string\":\"algo5\","
				+ "	\"int\":\"2147483647\","
				+ "	\"long\":\"9223372036854775807\","
				+ "	\"object4.object2.string\":\"algo9\","
				+ "	\"object.string\":\"algo2\","
				+ "	\"object4.object2.string2\":\"algo10\","
				+ "	\"object4.string\":\"algo6\","
				+ "	\"timestamp\":\"2022-06-27 12:09:12.000\","
				+ "	\"object3.string\":\"algo4\""
				+ "}";
		model = new UpdateOneModel<Document>(Filters.eq("string", "algo1").toBsonDocument(), new Document("$unset", objectMapper.readValue(updates, new TypeReference<Map<String, String>>(){})));
		writeModelMessages.add(model);		
		// ALGO2 D
		updates = "{"
				+ "	\"int\":\"2147483647\""
				+ "}";
		model = new UpdateOneModel<Document>(Filters.and(Filters.eq("string", "algo1"),Filters.eq("object1.object2.object3.int", "2147483647")), pull("object1.object2.object3", objectMapper.readValue(updates, new TypeReference<Map<String, String>>(){})));
		writeModelMessages.add(model);
		return writeModelMessages;
	}

}
