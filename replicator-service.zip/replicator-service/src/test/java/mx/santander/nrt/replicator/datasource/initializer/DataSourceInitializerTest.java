package mx.santander.nrt.replicator.datasource.initializer;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import mx.santander.nrt.replicator.configuration.ConfigurationProperties;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.mapping.PropertiesMapping;
import mx.santander.nrt.replicator.configuration.model.Channel;
import mx.santander.nrt.replicator.configuration.model.DataSourceConfig;
import mx.santander.nrt.replicator.datasource.IDataSource;
import mx.santander.nrt.replicator.datasource.KafkaDataSource;
import mx.santander.nrt.replicator.datasource.MongoDataSource;
import mx.santander.nrt.replicator.datasource.OracleDataSource;

class DataSourceInitializerTest {
	
	@Test
	void dataSourceOracleTest() {
		Map<String, Channel> channels = new HashMap<String, Channel>();
		Channel oracleChannel = new Channel();
		oracleChannel.setUrl("jdbc:oracle:thin:@//dbipadlm2mxr204.dev.mx.corp:1661/odmxipa3");
		oracleChannel.setDriveClasssName("oracle.jdbc.OracleDriver");
		oracleChannel.setPassword("");
		oracleChannel.setUsername("dehtlopie");
		channels.put("oracle", oracleChannel);
		Channel kafkaChannel = new Channel();
		kafkaChannel.setUrl("");
		kafkaChannel.setDriveClasssName("");
		kafkaChannel.setPassword("");
		kafkaChannel.setUsername("");
		kafkaChannel.setValidationQuery("");
		channels.put("kafka", kafkaChannel);
		Channel mongoChannel = new Channel();
		mongoChannel.setUrl("mongodb://localhost:29000");
		mongoChannel.setDatabase("nrtdatarep");
		mongoChannel.setCollectionName("nrt_collection_test");
		mongoChannel.setTestOnInit(false);
		channels.put("mongo", mongoChannel);
		
		DataSourceConfig datasourceConfig = new DataSourceConfig();
		datasourceConfig.setDefaultDataSource("oracle");
		datasourceConfig.setChannels(channels);
		PropertiesMapping propertiesMapping = new PropertiesMapping();
		propertiesMapping.setDatasourceConfig(datasourceConfig);
		IConfigurationProperties configurationProperties = new ConfigurationProperties(propertiesMapping );
		DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
		
		IDataSource dataSource = dataSourceInitializer.dataSource(configurationProperties);
		assertThat(dataSource).isExactlyInstanceOf(OracleDataSource.class);
		
		datasourceConfig.setDefaultDataSource("kafka");
		dataSource = dataSourceInitializer.dataSource(configurationProperties);
		assertThat(dataSource).isExactlyInstanceOf(KafkaDataSource.class);
		
		datasourceConfig.setDefaultDataSource("mongo");
		dataSource = dataSourceInitializer.dataSource(configurationProperties);
		assertThat(dataSource).isExactlyInstanceOf(MongoDataSource.class);
	}

}
