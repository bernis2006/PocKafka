package mx.santander.nrt.replicator.mq;

import java.util.ArrayList;
import java.util.List;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.assertj.core.api.Assertions.assertThat;

import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.model.RecordConfiguration;
import mx.santander.nrt.replicator.model.Record;
import mx.santander.nrt.replicator.service.IMessageService;

class MessageListenerTests {

	@Test
	void saveMessagesTest() throws JacksonException {
		String topic = "nrt_enr_test", key = "{\"buc\":\"00000875\"}";
			int partition = 14;
			long offset = 672540L;
		List<String> validMessages = getTestMessages();
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String message: validMessages) {
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));	
		}
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate(Mockito.anyString())).thenReturn(new RecordConfiguration());
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
		
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService).saveMessages(messagesCaptor.capture());
		List<Record> messages = messagesCaptor.getValue();
		assertThat(messages.size()).isEqualTo(validMessages.size());
		int i = 0;
		for (String message: validMessages) {
			assertThat(new ObjectMapper().readValue(message, Record.class)).usingRecursiveComparison().isEqualTo(messages.get(i));
			i++;
		}
	}
		
	@Test
	void saveValidAndInvalidMessagesTest() throws JacksonException {
		String topic = "nrt_enr_test", key = "{\"buc\":\"00000875\"}";
			int partition = 14;
			long offset = 672540L;
		List<String> validMessages = getTestMessages();
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String message: validMessages) {
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));	
		}
		records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, null));
		records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, ""));
		records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, "{\"metadata\": \"ALGO\"}"));
		records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, "a"));
		records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, "!\"#$%&/()="));
		records.add(null);
		
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate(Mockito.anyString())).thenReturn(new RecordConfiguration());
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
		
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService).saveMessages(messagesCaptor.capture());
		List<Record> messages = messagesCaptor.getValue();
		assertThat(messages.size()).isEqualTo(validMessages.size());
		int i = 0;
		for (String message: validMessages) {
			assertThat(new ObjectMapper().readValue(message, Record.class)).usingRecursiveComparison().isEqualTo(messages.get(i));
			assertThat(new ObjectMapper().readValue(message, Record.class).toString()).hasToString(messages.get(i).toString());
			i++;
		}
	}
	
	@Test
	void saveMessagesInvalidKeyTest() throws JacksonException {
		List<String> keys = new ArrayList<String>();
		keys.add("{\"buc\":\"\"}");
		keys.add("{\"buc\":\" \"}");
		keys.add("{\"buc\":{}}");
		keys.add("{\"buc\":null}");
		keys.add("{}");
		keys.add("null");
		keys.add("{\"algo\":\"00000875\"}");
		keys.add("{null:\"00000875\"}");
		keys.add("1");
//		keys.add("{\"buc\":false}");
//		keys.add("{\"buc\":1}");

		keys.add("{\"buc\":\" \"}");
		keys.add("{\"\":\"00000875\"}");
		keys.add("{\"buc\":\"\"}");
		keys.add("{\"buc\":null}");
		keys.add("{null:\"00000875\"}");
		keys.add(null);
		keys.add("{}");
		keys.add("1");
		keys.add("buc");
		keys.add("$%&/())(/&%");
		String topic = "nrt_enr_test";
			int partition = 14;
			long offset = 672540L;
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String key: keys) {
			String data = "{ \"PEPRIAPE\": \"DOMINGUEZ \", \"PESEGAPE\": \"DIAZ \", \"PENOMPER\": \"MICHEL GUADALUPE \", \"PETIPPER\": \"F\", \"PEINDNO1\": \"N\", \"PEINDNO2\": \"1\", \"PEARENEG\": \"007\", \"PEESTPER\": \"010\", \"PECONPER\": \"CLI\", \"PEFECNAC\": \"1997-05-01\", \"PEFECINI\": \"0001-01-01\", \"PEESTCIV\": \"S\", \"PESEXPER\": \"M\", \"PESUCADM\": \"7801\", \"PECANCAP\": \"022\", \"PEPAIORI\": \"056\", \"PENACPER\": \"056\", \"PEPAIRES\": \"056\", \"PESECPER\": \"013\", \"PETIPOCU\": \"  \", \"PECODACT\": \"01330001\", \"PETIERES\": \"0\", \"PEFORJUR\": \"  \", \"PENATJUR\": \"   \", \"PECODSUJ\": \"442\", \"PEBANPRI\": \" \", \"PEHSTAMP\": \"2021-12-02 14:09:21\", \"PECDGENT\": \"0014\", \"buc\": \"00000875\" }",
					message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));
		}
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate(Mockito.anyString())).thenReturn(new RecordConfiguration());
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
		
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService, Mockito.never()).saveMessages(messagesCaptor.capture());
		assertThat(messagesCaptor.getAllValues().size()).isEqualTo(0);
	}
	
	@Test
	void saveMessagesInvalidMetadataTest() throws JacksonException {
		String topic = "nrt_enr_test", key = "{\"buc\":\"00000875\"}";
			int partition = 14;
			long offset = 672540L;
			
		List<String> invalidMessages = new ArrayList<String>();
		String data = "{ \"PEPRIAPE\": \"DOMINGUEZ \", \"PESEGAPE\": \"DIAZ \", \"PENOMPER\": \"MICHEL GUADALUPE \", \"PETIPPER\": \"F\", \"PEINDNO1\": \"N\", \"PEINDNO2\": \"1\", \"PEARENEG\": \"007\", \"PEESTPER\": \"010\", \"PECONPER\": \"CLI\", \"PEFECNAC\": \"1997-05-01\", \"PEFECINI\": \"0001-01-01\", \"PEESTCIV\": \"S\", \"PESEXPER\": \"M\", \"PESUCADM\": \"7801\", \"PECANCAP\": \"022\", \"PEPAIORI\": \"056\", \"PENACPER\": \"056\", \"PEPAIRES\": \"056\", \"PESECPER\": \"013\", \"PETIPOCU\": \"  \", \"PECODACT\": \"01330001\", \"PETIERES\": \"0\", \"PEFORJUR\": \"  \", \"PENATJUR\": \"   \", \"PECODSUJ\": \"442\", \"PEBANPRI\": \" \", \"PEHSTAMP\": \"2021-12-02 14:09:21\", \"PECDGENT\": \"0014\", \"buc\": \"00000875\" }",
		stMessage = "{\"metadata\": {},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"TWESTREL\": \"A\",\"TWCDGENT\": \"0014\", \"TWNUMPER\":\"00000010\", \"TWCLVUNI\": \"005 \",\"TWCLVCAM\": \"IH001\",\"TWCLVCAR\": \"ADI \",\"TWTIPREL\": \"1 \",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": \"algo\",\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"CODIGO_PROMOCION\": \"SMS  \",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": null,\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PEPRETEL\": \"57     \",\"PECARTEL\": \"TE5  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"37\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": \"\",\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PEPRETEL\": \"56     \",\"PECARTEL\": \"TE  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"38\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": \" \",\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PETIPDOC\": \"CU\",\"PENUMERO\": \"GUPE810424HGTRNR00  \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"01\",\"buc\": \"00000875\"}";
		stMessage = "{\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PETIPDOC\": \"IF\",\"PENUMERO\": \"0378069552944       \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"02\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": 1,\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"ODSECTEL\": \"37\",\"ODESTUSO\": \"A\",\"ODUSOCEL\": \"001\",\"ODCDGENT\": \"0014\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": false,\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PESECMED\": \"1\",\"PEPARME1\": \"AB1                                              \",\"PEPARME2\": \"AB1                                              \",\"PEHSTAMP\": \"2022-01-20 11:55:08\",\"PETIPMED\": \"ELE\",\"PECDGENT\": \"0014\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": " + data + ",\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"ODUSOCOE\": \"001\",\"ODSECDOM\": \"1\",\"ODCDGENT\": \"0014\",\"ODESTUSO\": \"C\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String message: invalidMessages) {
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));	
		}
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate(Mockito.anyString())).thenReturn(new RecordConfiguration());
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
				
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService, Mockito.never()).saveMessages(messagesCaptor.capture());
		assertThat(messagesCaptor.getAllValues().size()).isEqualTo(0);
	}
	
	@Test
	void saveMessagesInvalidOperationTypeTest() throws JacksonException {
		String topic = "nrt_enr_test", key = "{\"buc\":\"00000875\"}";
			int partition = 14;
			long offset = 672540L;
			
		List<String> invalidMessages = new ArrayList<String>();
		String data = "{ \"PEPRIAPE\": \"DOMINGUEZ \", \"PESEGAPE\": \"DIAZ \", \"PENOMPER\": \"MICHEL GUADALUPE \", \"PETIPPER\": \"F\", \"PEINDNO1\": \"N\", \"PEINDNO2\": \"1\", \"PEARENEG\": \"007\", \"PEESTPER\": \"010\", \"PECONPER\": \"CLI\", \"PEFECNAC\": \"1997-05-01\", \"PEFECINI\": \"0001-01-01\", \"PEESTCIV\": \"S\", \"PESEXPER\": \"M\", \"PESUCADM\": \"7801\", \"PECANCAP\": \"022\", \"PEPAIORI\": \"056\", \"PENACPER\": \"056\", \"PEPAIRES\": \"056\", \"PESECPER\": \"013\", \"PETIPOCU\": \"  \", \"PECODACT\": \"01330001\", \"PETIERES\": \"0\", \"PEFORJUR\": \"  \", \"PENATJUR\": \"   \", \"PECODSUJ\": \"442\", \"PEBANPRI\": \" \", \"PEHSTAMP\": \"2021-12-02 14:09:21\", \"PECDGENT\": \"0014\", \"buc\": \"00000875\" }",
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"TWESTREL\": \"A\",\"TWCDGENT\": \"0014\", \"TWNUMPER\":\"00000010\", \"TWCLVUNI\": \"005 \",\"TWCLVCAM\": \"IH001\",\"TWCLVCAR\": \"ADI \",\"TWTIPREL\": \"1 \",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\" \",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"CODIGO_PROMOCION\": \"SMS  \",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"A\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PEPRETEL\": \"57     \",\"PECARTEL\": \"TE5  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"37\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":{},\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PEPRETEL\": \"56     \",\"PECARTEL\": \"TE  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"38\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":null,\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PETIPDOC\": \"CU\",\"PENUMERO\": \"GUPE810424HGTRNR00  \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"01\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PETIPDOC\": \"IF\",\"PENUMERO\": \"0378069552944       \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"02\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":1,\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String message: invalidMessages) {
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));	
		}
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate(Mockito.anyString())).thenReturn(new RecordConfiguration());
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
				
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService, Mockito.never()).saveMessages(messagesCaptor.capture());
		assertThat(messagesCaptor.getAllValues().size()).isEqualTo(0);
	}
	
	@Test
	void saveMessagesInvalidTableNameTest() throws JacksonException {
		String topic = "nrt_enr_test", key = "{\"buc\":\"00000875\"}";
			int partition = 14;
			long offset = 672540L;
			
		List<String> invalidMessages = new ArrayList<String>();
		String data = "{ \"PEPRIAPE\": \"DOMINGUEZ \", \"PESEGAPE\": \"DIAZ \", \"PENOMPER\": \"MICHEL GUADALUPE \", \"PETIPPER\": \"F\", \"PEINDNO1\": \"N\", \"PEINDNO2\": \"1\", \"PEARENEG\": \"007\", \"PEESTPER\": \"010\", \"PECONPER\": \"CLI\", \"PEFECNAC\": \"1997-05-01\", \"PEFECINI\": \"0001-01-01\", \"PEESTCIV\": \"S\", \"PESEXPER\": \"M\", \"PESUCADM\": \"7801\", \"PECANCAP\": \"022\", \"PEPAIORI\": \"056\", \"PENACPER\": \"056\", \"PEPAIRES\": \"056\", \"PESECPER\": \"013\", \"PETIPOCU\": \"  \", \"PECODACT\": \"01330001\", \"PETIERES\": \"0\", \"PEFORJUR\": \"  \", \"PENATJUR\": \"   \", \"PECODSUJ\": \"442\", \"PEBANPRI\": \" \", \"PEHSTAMP\": \"2021-12-02 14:09:21\", \"PECDGENT\": \"0014\", \"buc\": \"00000875\" }",
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"TWESTREL\": \"A\",\"TWCDGENT\": \"0014\", \"TWNUMPER\":\"00000010\", \"TWCLVUNI\": \"005 \",\"TWCLVCAM\": \"IH001\",\"TWCLVCAR\": \"ADI \",\"TWTIPREL\": \"1 \",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\" \",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"CODIGO_PROMOCION\": \"SMS  \",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT000\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PEPRETEL\": \"57     \",\"PECARTEL\": \"TE5  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"37\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":{},\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PEPRETEL\": \"56     \",\"PECARTEL\": \"TE  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"38\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":null,\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PETIPDOC\": \"CU\",\"PENUMERO\": \"GUPE810424HGTRNR00  \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"01\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PETIPDOC\": \"IF\",\"PENUMERO\": \"0378069552944       \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"02\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":1,\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"ODSECTEL\": \"37\",\"ODESTUSO\": \"A\",\"ODUSOCEL\": \"001\",\"ODCDGENT\": \"0014\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":false,\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"PESECMED\": \"1\",\"PEPARME1\": \"AB1                                              \",\"PEPARME2\": \"AB1                                              \",\"PEHSTAMP\": \"2022-01-20 11:55:08\",\"PETIPMED\": \"ELE\",\"PECDGENT\": \"0014\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"87654\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"ODUSOCOE\": \"001\",\"ODSECDOM\": \"1\",\"ODCDGENT\": \"0014\",\"ODESTUSO\": \"C\",\"buc\": \"00000875\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"/&%$\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String message: invalidMessages) {
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));	
		}
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate("PEDT000")).thenReturn(null);
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
				
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService, Mockito.never()).saveMessages(messagesCaptor.capture());
		assertThat(messagesCaptor.getAllValues().size()).isEqualTo(0);
	}
	
	@Test
	void saveMessagesInvalidDataTest() throws JacksonException {
		String topic = "nrt_enr_test", key = "{\"buc\":\"00000875\"}";
			int partition = 14;
			long offset = 672540L;
			
		List<String> invalidMessages = new ArrayList<String>();
		String data = "",
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "\"\"";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "1";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "null";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "false";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "[]";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
		data = "{\"\"}";
		stMessage = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		invalidMessages.add(stMessage);
				
		List<ConsumerRecord<String, String>> records = new ArrayList<ConsumerRecord<String,String>>();
		for (String message: invalidMessages) {
			records.add(new ConsumerRecord<String, String>(topic, partition, offset, key, message));	
		}
		IMessageService messageService = Mockito.mock(IMessageService.class);
		IConfigurationProperties configurationProperties = Mockito.mock(IConfigurationProperties.class);
		Mockito.when(configurationProperties.getTableToReplicate(Mockito.anyString())).thenReturn(new RecordConfiguration());
		MessageListener messageListener = new MessageListener(messageService, configurationProperties);
		messageListener.saveMessages(records);
				
		ArgumentCaptor<List<Record>> messagesCaptor = ArgumentCaptor.forClass(List.class);
		Mockito.verify(messageService, Mockito.never()).saveMessages(messagesCaptor.capture());
		assertThat(messagesCaptor.getAllValues().size()).isEqualTo(0);
	}
	
	private List<String> getTestMessages() {
		List<String> messages = new ArrayList<String>();
		String data = "{ \"PEPRIAPE\": \"DOMINGUEZ \", \"PESEGAPE\": \"DIAZ \", \"PENOMPER\": \"MICHEL GUADALUPE \", \"PETIPPER\": \"F\", \"PEINDNO1\": \"N\", \"PEINDNO2\": \"1\", \"PEARENEG\": \"007\", \"PEESTPER\": \"010\", \"PECONPER\": \"CLI\", \"PEFECNAC\": \"1997-05-01\", \"PEFECINI\": \"0001-01-01\", \"PEESTCIV\": \"S\", \"PESEXPER\": \"M\", \"PESUCADM\": \"7801\", \"PECANCAP\": \"022\", \"PEPAIORI\": \"056\", \"PENACPER\": \"056\", \"PEPAIRES\": \"056\", \"PESECPER\": \"013\", \"PETIPOCU\": \"  \", \"PECODACT\": \"01330001\", \"PETIERES\": \"0\", \"PEFORJUR\": \"  \", \"PENATJUR\": \"   \", \"PECODSUJ\": \"442\", \"PEBANPRI\": \" \", \"PEHSTAMP\": \"2021-12-02 14:09:21\", \"PECDGENT\": \"0014\", \"buc\": \"00000875\" }",
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910576510379032576\",\"table_name\":\"PEDT001\",\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\",\"operation_ts\":\"2022-01-13 14:08:19.417000000000\",\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"TWESTREL\": \"A\",\"TWCDGENT\": \"0014\", \"TWNUMPER\":\"00000010\", \"TWCLVUNI\": \"005 \",\"TWCLVCAM\": \"IH001\",\"TWCLVCAR\": \"ADI \",\"TWTIPREL\": \"1 \",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TWDTACU\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"CODIGO_PROMOCION\": \"SMS  \",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"TCL05_DATOSWEB\",\"operation_utc_ts\": \"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"PEPRETEL\": \"57     \",\"PECARTEL\": \"TE5  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"37\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"PEDT023\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"PEPRETEL\": \"56     \",\"PECARTEL\": \"TE  \",\"PENUMTEL\": \"28423652\",\"PESECTEL\": \"38\",\"PETIPTEL\": \"001\",\"PEHSTAMP\": \"2022-01-19 13:21:13\",\"PECLATEL\": \"001\",\"PECDGENT\": \"0014\",\"PESECDOM\": \"1\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"PEDT023\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"PETIPDOC\": \"CU\",\"PENUMERO\": \"GUPE810424HGTRNR00  \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"01\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"PEDT150\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"PETIPDOC\": \"IF\",\"PENUMERO\": \"0378069552944       \",\"PECDGENT\": \"0014\",\"PESECDOC\": \"02\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"PEDT150\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"ODSECTEL\": \"37\",\"ODESTUSO\": \"A\",\"ODUSOCEL\": \"001\",\"ODCDGENT\": \"0014\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"ODDTUTC\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"PESECMED\": \"1\",\"PEPARME1\": \"AB1                                              \",\"PEPARME2\": \"AB1                                              \",\"PEHSTAMP\": \"2022-01-20 11:55:08\",\"PETIPMED\": \"ELE\",\"PECDGENT\": \"0014\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"PEDT115\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		data = "{\"ODUSOCOE\": \"001\",\"ODSECDOM\": \"1\",\"ODCDGENT\": \"0014\",\"ODESTUSO\": \"C\",\"buc\": \"00000875\"}";
		message = "{\"metadata\": {\"buc\":\"00000875\",\"operation_type\":\"R\",\"commit_cycle_id\":\"1910574346914037760\",\"table_name\":\"ODDTUCE\",\"operation_utc_ts\":\"2022-01-13 19:11:39.289000000000\",\"operation_ts\":\"2022-01-13 13:11:39.289000000000\",\"transform_ts\":\"2022-01-13T19:11:20.881573034Z\"},\"data\": " + data + "}";
		messages.add(message);
		return messages;
	}

}
