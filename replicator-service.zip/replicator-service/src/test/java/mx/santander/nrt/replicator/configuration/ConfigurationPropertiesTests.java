package mx.santander.nrt.replicator.configuration;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import mx.santander.nrt.replicator.configuration.mapping.PropertiesMapping;
import mx.santander.nrt.replicator.configuration.model.Channel;
import mx.santander.nrt.replicator.configuration.model.DataSourceConfig;

class ConfigurationPropertiesTests {
	
	@Test
	void dataSourceTest() {
		Map<String, Channel> channels = new HashMap<String, Channel>();
		Channel mongoChannel = new Channel();
		mongoChannel.setUrl("mongodb://localhost:27017");
		mongoChannel.setDatabase("nrtdatarep");
		mongoChannel.setCollectionName("nrt_collection_test");
		channels.put("mongo", mongoChannel);
		Channel oracleChannel = new Channel();
		oracleChannel.setUrl("jdbc:oracle:thin:@//dbipadlm2mxr204.dev.mx.corp:1661/odmxipa3");
		oracleChannel.setDriveClasssName("oracle.jdbc.OracleDriver");
		oracleChannel.setPassword("");
		oracleChannel.setUsername("dehtlopie");
		channels.put("oracle", oracleChannel);
		DataSourceConfig datasourceConfig = new DataSourceConfig();
		datasourceConfig.setChannels(channels);
		PropertiesMapping propertiesMapping = new PropertiesMapping();
		propertiesMapping.setDatasourceConfig(datasourceConfig);
		ConfigurationProperties configurationProperties = new ConfigurationProperties(propertiesMapping);
		configurationProperties.printConfiguration();
		IConfigurationProperties iConfigurationProperties = new ConfigurationProperties(propertiesMapping);
		
		assertThat(iConfigurationProperties.getDefaultChannel()).usingRecursiveComparison().isEqualTo(mongoChannel);
		datasourceConfig.setDefaultDataSource("oracle");
		assertThat(iConfigurationProperties.getDefaultChannel()).usingRecursiveComparison().isEqualTo(oracleChannel);
		
		PropertiesMapping currentConfig = iConfigurationProperties.getConfiguration();

		assertThat(currentConfig.toString()).hasToString(propertiesMapping.toString());
	}
}