package mx.santander.nrt.replicator.processor;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import mx.santander.nrt.replicator.configuration.ConfigurationProperties;
import mx.santander.nrt.replicator.configuration.IConfigurationProperties;
import mx.santander.nrt.replicator.configuration.mapping.PropertiesMapping;
import mx.santander.nrt.replicator.configuration.model.FieldConfiguration;
import mx.santander.nrt.replicator.configuration.model.RecordConfiguration;
import mx.santander.nrt.replicator.model.Record;

class RecordProcessorTests {
	
	@Test
	void transformValidMessagesTest() throws JacksonException {
		Map<String, RecordConfiguration> tablesToReplicate = createTablesToReplicateConfiguration();
		PropertiesMapping propertiesMapping = new PropertiesMapping();
		propertiesMapping.setTablesToReplicate(tablesToReplicate);
		
		RecordConfiguration pedt001Table = propertiesMapping.getTableToReplicate("PEDT001");
		pedt001Table.toString();
		FieldConfiguration fieldConfig = pedt001Table.getFieldsConfig().get("PEPRIAPE");
		fieldConfig.toString();
		
		IConfigurationProperties configurationProperties = new ConfigurationProperties(propertiesMapping);
		IRecordProcessor recordProcessor = new RecordProcessor(configurationProperties);

		List<Record> transformedRecords = recordProcessor.transformMessage(getRecords());
		assertThat(transformedRecords.get(0).getData()).isNull();
		List<Record> expectedTransformedRecords = getExtectedTransformedMessage();
		
		int i = 0;
		for (Record record: expectedTransformedRecords) {
			assertThat(transformedRecords.get(i)).usingRecursiveComparison().isEqualTo(record);
			i++;
		}
	}
	
	private List<Record> getRecords() throws JacksonException {
		List<Record> records = new ArrayList<Record>();
		String data = "{\"PEPRIAPE\": \"DOMINGUEZ \",\"PESEGAPE\": \"DIAZ \",\"PENOMPER\": \"MICHEL GUADALUPE \",\"PETIPPER\": \"F\",\"PEINDNO1\": \"N\",\"PEINDNO2\": \"1\",\"PEARENEG\": \"007\",\"PEESTPER\": \"010\",\"PECONPER\": \"CLI\",\"PEFECNAC\": \"1997-05-01\",\"PEFECINI\": \"0001-01-01\",\"PEESTCIV\": \"S\",\"PESEXPER\": \"M\",\"PESUCADM\": \"7801\",\"PECANCAP\": \"022\",\"PEPAIORI\": \"056\",\"PENACPER\": \"056\",\"PEPAIRES\": \"056\",\"PESECPER\": \"013\",\"PETIPOCU\": \"  \",\"PECODACT\": \"01330001\",\"PETIERES\": \"0\",\"PEFORJUR\": \"  \",\"PENATJUR\": \"   \",\"PECODSUJ\": \"442\",\"PEBANPRI\": \" \",\"PEHSTAMP\": \"2021-12-02 14:09:21\",\"PECDGENT\": \"0014\",\"buc\": \"00000875\"}",
		message = "{\"metadata\": {\"operation_type\": \"R\",\"commit_cycle_id\": \"1910576510379032576\",\"table_name\": \"PEDT001\",\"operation_utc_ts\": \"2022-01-13 20:08:19.417000000000\",\"operation_ts\": \"2022-01-13 14:08:19.417000000000\",\"transform_ts\": \"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		records.add(new ObjectMapper().readValue(message, Record.class));
		data = "{\"ALGO-TIMESTAMP\":\"2022-06-27 12:09:12.000\",\"ALGO-DATE\":\"2022-06-27\",\"ALGO-STRING\":\"algo1\",\"ALGO-INT\":\"2147483647\",\"ALGO-LONG\":\"9223372036854775807\",\"ALGO-DOUBLE\":\"3.13457599923384753929348D\",\"ALGO-OBJECT-STRING\":\"algo2\", \"ALGO-OBJECT2-OBJECT-STRING\":\"algo3\",\"ALGO-OBJECT3-STRING\":\"algo4\",\"ALGO-OBJECT3-OBJECT-STRING\":\"algo5\",\"ALGO-OBJECT4-STRING\":\"algo6\",\"ALGO-OBJECT4-STRING2\":\"algo7\",\"ALGO-OBJECT4-OBJECT-STRING\":\"algo8\",\"ALGO-OBJECT4-OBJECT2-STRING\":\"algo9\",\"ALGO-OBJECT4-OBJECT2-STRING2\":\"algo10\"}";
		message = "{\"metadata\": {\"operation_type\": \"R\",\"commit_cycle_id\": \"1910576510379032576\",\"table_name\": \"ALGO\",\"operation_utc_ts\": \"2022-01-13 20:08:19.417000000000\",\"operation_ts\": \"2022-01-13 14:08:19.417000000000\",\"transform_ts\": \"2022-01-13T20:07:58.482205722Z\"},\"data\": " + data + "}";
		records.add(new ObjectMapper().readValue(message, Record.class));
		return records;
	}
	
	
	private Map<String, RecordConfiguration> createTablesToReplicateConfiguration() throws JacksonException {
		String config = "{"
				+ "	\"PEDT001\": {"
				+ "		\"fieldsConfig\": {"
				+ "			\"PEPRIAPE\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.personName.paternalName\""
				+ "			},"
				+ "			\"PESEGAPE\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.personName.maternalName\""
				+ "			},"
				+ "			\"PENOMPER\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.personName.givenName\""
				+ "			},"
				+ "			\"PETIPPER\": {"
				+ "				\"location\": \"partyInfo.customerType\""
				+ "			},"
				+ "			\"PEINDNO1\": {"
				+ "				\"location\": \"partyInfo.peindno1\""
				+ "			},"
				+ "			\"PEINDNO2\": {"
				+ "				\"location\": \"partyInfo.fiscalActivityInd\""
				+ "			},"
				+ "			\"PEARENEG\": {"
				+ "				\"location\": \"partyInfo.serviceLevelCode\""
				+ "			},"
				+ "			\"PEESTPER\": {"
				+ "				\"location\": \"partyStatus.partyAdditionalStatusCode\""
				+ "			},"
				+ "			\"PECONPER\": {"
				+ "				\"location\": \"partyStatus.partyStatusCode\""
				+ "			},"
				+ "			\"PEFECNAC\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.birthDt\""
				+ "			},"
				+ "			\"PEFECINI\": {"
				+ "				\"location\": \"partyInfo.establishedDt\""
				+ "			},"
				+ "			\"PEESTCIV\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.maritalStat\""
				+ "			},"
				+ "			\"PESEXPER\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.gender\""
				+ "			},"
				+ "			\"PESUCADM\": {"
				+ "				\"location\": \"partyInfo.personPartyInfo.originatingBranchCode\""
				+ "			},"
				+ "			\"PECANCAP\": {"
				+ "				\"location\": \"partyInfo.originatingChannelCode\""
				+ "			},"
				+ "			\"PEPAIORI\": {"
				+ "				\"location\": \"partyInfo.birthCountry.countryCodeValue\""
				+ "			},"
				+ "			\"PENACPER\": {"
				+ "				\"location\": \"partyInfo.nationalityCountry.countryCodeValue\""
				+ "			},"
				+ "			\"PEPAIRES\": {"
				+ "				\"location\": \"partyInfo.residenceCountry.countryCodeValue\""
				+ "			},"
				+ "			\"PESECPER\": {"
				+ "				\"location\": \"partyInfo.occupationData.genericActivityCode\""
				+ "			},"
				+ "			\"PETIPOCU\": {"
				+ "				\"location\": \"partyInfo.occupationData.occupationCode\""
				+ "			},"
				+ "			\"PECODACT\": {"
				+ "				\"location\": \"partyInfo.occupationData.specificActivityCode\""
				+ "			},"
				+ "			\"PETIERES\": {"
				+ "				\"location\": \"partyInfo.residenceCountry.timeFrame.duration.count\""
				+ "			},"
				+ "			\"PEFORJUR\": {"
				+ "				\"location\": \"partyInfo.orgPartyInfo.legalForm\""
				+ "			},"
				+ "			\"PENATJUR\": {"
				+ "				\"location\": \"partyInfo.legalEntity\""
				+ "			},"
				+ "			\"PECODSUJ\": {"
				+ "				\"location\": \"partyInfo.accountingField\""
				+ "			},"
				+ "			\"PEBANPRI\": {"
				+ "				\"location\": \"partyInfo.privateBankingInd\""
				+ "			},"
				+ "			\"PEHSTAMP\": {"
				+ "				\"location\": \"partyEnvr.lastUpdateDt\""
				+ "			},"
				+ "			\"PECDGENT\": {"
				+ "				\"location\": \"partyInfo.entity\""
				+ "			},"
				+ "			\"buc\": {"
				+ "				\"location\": \"partyId\""
				+ "			}"
				+ "		}"
				+ "	},"
				+ "	\"ALGO\": {"
				+ "		\"fieldsConfig\": {"
				+ "			\"ALGO-STRING\": {"
				+ "				\"location\": \"string\""
				+ "			},"
				+ "			\"ALGO-TIMESTAMP\": {"
				+ "				\"location\": \"timestamp\""
				+ "			},"
				+ "			\"ALGO-DATE\": {"
				+ "				\"location\": \"date\""
				+ "			},"
				+ "			\"ALGO-INT\": {"
				+ "				\"location\": \"int\""
				+ "			},"
				+ "			\"ALGO-LONG\": {"
				+ "				\"location\": \"long\""
				+ "			},"
				+ "			\"ALGO-DOUBLE\": {"
				+ "				\"location\": \"double\""
				+ "			},"
				+ "			\"ALGO-OBJECT-STRING\": {"
				+ "				\"location\": \"object.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT2-OBJECT-STRING\": {"
				+ "				\"location\": \"object2.object.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT3-STRING\": {"
				+ "				\"location\": \"object3.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT3-OBJECT-STRING\": {"
				+ "				\"location\": \"object3.object.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT4-STRING\": {"
				+ "				\"location\": \"object4.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT4-STRING2\": {"
				+ "				\"location\": \"object4.string2\""
				+ "			},"
				+ "			\"ALGO-OBJECT4-OBJECT-STRING\": {"
				+ "				\"location\": \"object4.object.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT4-OBJECT2-STRING\": {"
				+ "				\"location\": \"object4.object2.string\""
				+ "			},"
				+ "			\"ALGO-OBJECT4-OBJECT2-STRING2\": {"
				+ "				\"location\": \"object4.object2.string2\""
				+ "			}"
				+ "		}	"
				+ "	}"
				+ "}";
		 return new ObjectMapper().readValue(config, new TypeReference<Map<String, RecordConfiguration>>(){});
	}
	
	private List<Record> getExtectedTransformedMessage() throws JacksonException {
		String message = "["
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"PEDT001\", "
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\", "
				+ "			\"commit_cycle_id\":1910576510379032576, "
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\", "
				+ "			\"operation_type\":\"R\", "
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		}, "
				+ "		\"data\":null, "
				+ "		\"message\":{"
				+ "			\"partyStatus\":{"
				+ "				\"partyAdditionalStatusCode\":\"010\","
				+ "				\"partyStatusCode\":\"CLI\""
				+ "			},"
				+ "			\"partyInfo\":{"
				+ "				\"residenceCountry\":{"
				+ "					\"countryCodeValue\":\"056\","
				+ "					\"timeFrame\":{"
				+ "						\"duration\":{"
				+ "							\"count\":\"0\""
				+ "						}"
				+ "					}"
				+ "				},"
				+ "				\"peindno1\":\"N\","
				+ "				\"originatingChannelCode\":\"022\","
				+ "				\"serviceLevelCode\":\"007\","
				+ "				\"personPartyInfo\":{"
				+ "					\"personName\":{"
				+ "						\"paternalName\":\"DOMINGUEZ \","
				+ "						\"maternalName\":\"DIAZ \","
				+ "						\"givenName\":\"MICHEL GUADALUPE \""
				+ "					},"
				+ "					\"birthDt\":\"1997-05-01\","
				+ "					\"maritalStat\":\"S\","
				+ "					\"gender\":\"M\","
				+ "					\"originatingBranchCode\":\"7801\""
				+ "				},"
				+ "				\"accountingField\":\"442\","
				+ "				\"legalEntity\":\"   \","
				+ "				\"establishedDt\":\"0001-01-01\","
				+ "				\"customerType\":\"F\","
				+ "				\"orgPartyInfo\":{"
				+ "					\"legalForm\":\"  \""
				+ "				},"
				+ "				\"birthCountry\":{"
				+ "					\"countryCodeValue\":\"056\""
				+ "				},"
				+ "				\"occupationData\":{"
				+ "					\"genericActivityCode\":\"013\","
				+ "					\"occupationCode\":\"  \","
				+ "					\"specificActivityCode\":\"01330001\""
				+ "				},"
				+ "				\"fiscalActivityInd\":\"1\","
				+ "				\"privateBankingInd\":\" \","
				+ "				\"entity\":\"0014\","
				+ "				\"nationalityCountry\":{"
				+ "					\"countryCodeValue\":\"056\""
				+ "				}"
				+ "			},"
				+ "			\"partyId\":\"00000875\","
				+ "			\"partyEnvr\":{"
				+ "				\"lastUpdateDt\":\"2021-12-02 14:09:21\""
				+ "			}"
				+ "		}"
				+ "	},"
				+ "	{"
				+ "		\"metadata\":{"
				+ "			\"table_name\":\"ALGO\", "
				+ "			\"operation_utc_ts\":\"2022-01-13 20:08:19.417000000000\", "
				+ "			\"commit_cycle_id\":1910576510379032576, "
				+ "			\"operation_ts\":\"2022-01-13 14:08:19.417000000000\", "
				+ "			\"operation_type\":\"R\", "
				+ "			\"transform_ts\":\"2022-01-13T20:07:58.482205722Z\""
				+ "		}, "
				+ "		\"data\":null, "
				+ "		\"message\":{"
				+ "			\"string\": \"algo1\","
				+ "			\"timestamp\": \"2022-06-27 12:09:12.000\","
				+ "			\"date\": \"2022-06-27\","
				+ "			\"int\": \"2147483647\","
				+ "			\"long\": \"9223372036854775807\","
				+ "			\"double\": \"3.13457599923384753929348D\","
				+ "			\"object\": {"
				+ "				\"string\": \"algo2\""
				+ "			},"
				+ "			\"object2\": {"
				+ "				\"object\" : {"
				+ "					\"string\": \"algo3\""
				+ "				}"
				+ "			},"
				+ "			\"object3\": {"
				+ "				\"string\": \"algo4\","
				+ "				\"object\" : {"
				+ "					\"string\": \"algo5\""
				+ "				}"
				+ "			},"
				+ "			\"object4\": {"
				+ "				\"string\": \"algo6\","
				+ "				\"string2\": \"algo7\","
				+ "				\"object\" : {"
				+ "					\"string\": \"algo8\""
				+ "				},"
				+ "				\"object2\" : {"
				+ "					\"string\": \"algo9\","
				+ "					\"string2\": \"algo10\""
				+ "				}"
				+ "			}"
				+ "		}"
				+ "	}"
				+ "]";
		return new ObjectMapper().readValue(message, new TypeReference<List<Record>>(){});
	}

}
